import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class RestService {

  url:string="http://192.168.76.85:8080/login"
  constructor(private http:HttpClient) { }

  auth(user){
    return this.http.post(this.url,user).toPromise();
  }
}
