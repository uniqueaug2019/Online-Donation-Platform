import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private svc: RestService) { }

  ngOnInit() {
  }

  login(user) {
    this.svc.auth(user).then(response => {
      console.log(response);
    }).catch(error => {
      console.log(error);

    }
    )
  }

}
