package spring.donation.donation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.pojos.Category;

@RestController
public class CategoryController {

@Autowired
ICategoryDao dao;
	
@RequestMapping("/getallproducts")
public List<Category> Getall()
{
	return dao.findAll();
}

}
