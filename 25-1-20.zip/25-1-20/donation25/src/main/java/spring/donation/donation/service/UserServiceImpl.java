package spring.donation.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Address;
import spring.donation.donation.pojos.Contact;
import spring.donation.donation.pojos.User;

@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	IUserDao dao;

	@Override
	public User authenticate(String user){
		System.out.println("in user authenticate");
		ObjectMapper mapper = new ObjectMapper();
		// convert to json object
		JsonNode jsonNode = null;
		try {
			jsonNode = mapper.readTree(user);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		String email = jsonNode.get("email").asText();
		String password = jsonNode.get("password").asText();
		List<User> t = dao.findByEmailAndPassword(email, password);
		// get user form 0th index as it is stored in 0th index
		User tempuser = t.get(0);
		tempuser.setPassword("N/A");
		return tempuser;
	}

	@Override
	public boolean register(String user) {
		boolean status = false;

		ObjectMapper mapper = new ObjectMapper();
		// convert to json object
		JsonNode jsonNode = null;
		try {
			jsonNode = mapper.readTree(user);
		} catch (JsonMappingException e) {			
			e.printStackTrace();
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}
		System.out.println(jsonNode.toString());
		// get value for a key
		// System.out.println(jsonNode.get("dOB").asText());
		// converting json data to proper datatype
		String name = jsonNode.get("name").asText();
		String email = jsonNode.get("email").asText();
		String password = jsonNode.get("password").asText();
		String dOB = jsonNode.get("dOB").asText();
		String add = jsonNode.get("add").asText();
		int contactNo = jsonNode.get("contactNo").asInt();
		int pinCode = jsonNode.get("pinCode").asInt();
		// create user
		User u = new User(name, email, password, dOB, new Contact(contactNo));
		// create address
		Address a = new Address(add, pinCode);
		// add address using helper function
		u.addAddress(a);
		// save into db
		dao.save(u);
		return status;

	}

	@Override
	public boolean ChangePassword(String email, String password) {
		boolean status = false;
		User u = null;
		
		try {
			//get user by email password directly can't be changed else generate illegal state exception
			//fetch pojo to change password
			List<User> ul = dao.findByUserEmail(email);
			//Available at 0th location
			u = ul.get(0);
			//setting password
			u.setPassword(password);
			//persist the pojo
			u = dao.save(u);
		} catch (Exception e) {
			System.out.println("errro in db");
		}

		if (u != null) {
			status = true;
		}
		return status;
	}

	@Override
	public List<User> getAlluser() {
		List<User>userlist=dao.findAll();
		for(User u:userlist)
		{
			u.setPassword("N/A");
		}
		return userlist;
	}
}