package spring.donation.donation.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.util.JSONPObject;

import spring.donation.donation.pojos.User;

public interface IUserService {
public User authenticate(String user);
public boolean register(String user) ;
public boolean ChangePassword(String email,String password);
public List<User> getAlluser();
}
