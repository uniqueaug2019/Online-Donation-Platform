package spring.donation.donation.service;

public interface IElectronicService {
public boolean insertElectronic(String electronic);
}
