package spring.donation.donation.pojos;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class image {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
private Integer id;
private String name;
private String type;
private byte[] pic;
public image() {
	// TODO Auto-generated constructor stub
}
public image(String name, String type, byte[] pic) {
	super();
	this.name = name;
	this.type = type;
	this.pic = pic;
}

public image(byte[] pic) {
	super();
	this.pic = pic;
}
@Override
public String toString() {
	return "image [id=" + id + ", name=" + name + ", type=" + type + ", pic=" + Arrays.toString(pic) + "]";
}

}
