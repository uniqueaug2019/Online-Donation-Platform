package spring.donation.donation.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Books {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer bookId;
	@Column(length=25)
	private String bookName;
	private String bookDetails;
	private int bookQuantity;
	private String suggestion;

	@ManyToOne
	@JoinColumn(name = "categoryId")
	@JsonBackReference
	private Category selectedCategory;

	@ManyToOne
	@JoinColumn(name = "userId")
	@JsonBackReference
	private User bookuser;

	public User getBookuser() {
		return bookuser;
	}

	public void setBookuser(User bookuser) {
		this.bookuser = bookuser;
	}

	public Books() {
		System.out.println("inside book CTOR");
	}

	public Books(String bookName, String bookDetails, int bookQuantity, Category selectedCategory,String suggestion) {
		super();
		
		this.bookName = bookName;
		this.bookDetails = bookDetails;
		this.bookQuantity = bookQuantity;
		this.selectedCategory = selectedCategory;
		this.suggestion = suggestion;
	}

	public Books(String bookName, String bookDetails, int bookQuantity,String suggestion) {
		super();
		this.bookName = bookName;
		this.bookDetails = bookDetails;
		this.bookQuantity = bookQuantity;
		this.suggestion = suggestion;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(String suggestion) {
		 this.suggestion = suggestion;
	}

	public String getBookDetails() {
		return bookDetails;
	}

	public void setBookDetails(String bookDetails) {
		this.bookDetails = bookDetails;
	}

	public int getBookQuantity() {
		return bookQuantity;
	}

	public void setBookQuantity(int bookQuantity) {
		this.bookQuantity = bookQuantity;
	}

	public Category getSelectedCategory() {
		return selectedCategory;
	}

	public void setSelectedCategory(Category selectedCategory) {
		this.selectedCategory = selectedCategory;
	}

	@Override
	public String toString() {
		return "Books [bookId=" + bookId + ", bookName=" + bookName + ", bookDetails=" + bookDetails + ", bookQuantity="
				+ bookQuantity + ", suggestion=" + suggestion + ", selectedCategory=" + selectedCategory + ", bookuser="
				+ bookuser + "]";
	}

	
}
