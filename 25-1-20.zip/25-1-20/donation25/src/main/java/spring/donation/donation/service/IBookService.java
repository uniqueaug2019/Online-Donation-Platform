package spring.donation.donation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface IBookService {
	public boolean InsertBook(String book) throws Exception;
}
