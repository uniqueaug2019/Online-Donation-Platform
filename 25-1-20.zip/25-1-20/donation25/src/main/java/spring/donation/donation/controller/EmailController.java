package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value="/email")
public class EmailController {
	
	@Autowired
	public JavaMailSender javaMailSender;
	
	@RequestMapping(value="/sendEmail" ,method = RequestMethod.POST)
	public String sendmail(@RequestBody String emailstr){
		
		ObjectMapper mapper=new ObjectMapper();
		JsonNode node = null;
		try {
			node = mapper.readTree(emailstr);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		String email=node.get("email").asText(); 		
		final String  path="http://192.168.76.217:8080/reset/01010/email-reset-09/12334fadgh/retgsfdvcxhtrsdhfAHGD/AspassNfdgfds";
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo(email);
		message.setSubject("Reset Password");
		message.setText("Reset Your Helping Wall Password By Clicking on Following Link below : "+path);		
		javaMailSender.send(message);
		return"Succesfully email sended";
	}
	
	@RequestMapping(value="/sendProductUpdateMail" ,method = RequestMethod.POST)
	public String sendProductUpdateMail(@RequestBody String emailstr)  {
		
		ObjectMapper mapper=new ObjectMapper();
		JsonNode node = null;
		try {
			node = mapper.readTree(emailstr);
		} catch (JsonMappingException e) {
			System.out.println("JsonMappingException Occured");
		} catch (JsonProcessingException e) {
			System.out.println("JsonProcessingException Occured");
		}		
		String email=node.get("email").asText();
		String productName =node.get("productName").asText();	
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo(email);
		message.setSubject("Donated Product Update");
		message.setText("Thank you for donating "+productName+"\n We are Happy we have Donator like YOU:)");		
		javaMailSender.send(message);
		return"Product update Mail Succesfully  sended";
	}
}
