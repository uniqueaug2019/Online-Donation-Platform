package spring.donation.donation.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer categoryId;
	private String categoryName;

	@OneToMany(mappedBy = "selectedCategory", cascade = CascadeType.ALL,orphanRemoval = true)
	@JsonManagedReference
	private List<Books> book = new ArrayList<>();

	@OneToMany(mappedBy = "electronicCategory", cascade = CascadeType.ALL,orphanRemoval = true)
	@JsonManagedReference
	private List<Electronics> electronic = new ArrayList<>();

	public Category() {
		System.out.println("Inside Category CTOR");
	}

	public Category(String categoryName, User catuser, List<Books> book) {
		super();
		this.categoryName = categoryName;
		this.book = book;
	}

	public Category(String categoryName, List<Books> book) {
		super();
		this.categoryName = categoryName;
		this.book = book;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<Books> getBook() {
		return book;
	}

	public void setBook(List<Books> book) {
		this.book = book;
	}

	// helper function for adding book
	public void addBook(Books b) {
		book.add(b);
		b.setSelectedCategory(this);
	}

	// helper function for removing book
	public void removeBook(Books b) {
		book.remove(b);
		b.setSelectedCategory(null);
	}

	// helper function to add electronic
	public void addElectronic(Electronics e) {
		electronic.add(e);
		e.setElectronicCategory(this);
	}

	// helper function to remove electronic
	public void removeElectronic(Electronics e) {
		electronic.remove(e);
		e.setElectronicCategory(null);
	}

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", catuser=" + ", book=" + book
				+ "]";
	}

}
