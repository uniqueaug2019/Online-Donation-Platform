import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyproducts',
  templateUrl: './buyproducts.component.html',
  styleUrls: ['./buyproducts.component.css']
})
export class BuyproductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
