import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../helper/mustmatch';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;

  regUser: any;
status:boolean=false;
msg:string="";

  selectedFile: File;


  constructor(private svc: RestService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({

      name: ['', Validators.required],

      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      dob: ['', Validators.required],
      pincode: ['', Validators.required],
      contactNo: ['', Validators.required],
      add: ['', Validators.required],
      image: ['']

    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
  }
  get f() { return this.registerForm.controls; }



  onFileChanged(event) {
    this.selectedFile = event.target.files[0]
    console.log(this.selectedFile);
    
  }



  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }


    console.log(this.registerForm);

    this.regUser = {
      name: this.registerForm.value.name,
      email: this.registerForm.value.email,
      password: this.registerForm.value.password,
      dOB: this.registerForm.value.dob,
      contactNo: this.registerForm.value.contactNo,
      pinCode: this.registerForm.value.pincode,
      add: this.registerForm.value.add,
      image:this.selectedFile
    }
    console.log(this.regUser);
    this.register(this.regUser);
    // display form values on success
    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));

    

  }

  onReset() {
    this.submitted = false;
    this.registerForm.reset();
  }


 

 

  // onUpload() {
  //   // upload code goes here
  // }





  register(user) {
    this.svc.register(user).then(response => {
      console.log(response);
      this.status = true;
      this.msg = "Register successful";

    }).catch(error => {
      console.log(error);
      this.msg = "Register unsuccessful";

    }
    )
  }







  // onUpload() {
  //   // this.http is the injected HttpClient
  //   const uploadData = new FormData();
  //   uploadData.append('myFile', this.selectedFile, this.selectedFile.name);
  //   this.http.post('my-backend.com/file-upload', uploadData)
  //     .subscribe(...);
  // }
  // Listen to upload progress
  
  // In both cases, you can listen to the upload progress by editing the above code like this:
  
  // onUpload() {
  //   ...
  //   this.http.post('my-backend.com/file-upload', uploadData, {
  //     reportProgress: true,
  //     observe: 'events'
  //   })
  //     .subscribe(event => {
  //       console.log(event); // handle event here
  //     });
  // }
}
