import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductlistService {

  constructor() { }

  products: [
    {

      book_id: 1,
      book_details: "auydfawe",
      book_name: "euiwhgfuiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    }

    ,
    {

      book_id: 2,
      book_details: "eWFawe",
      book_name: "Efqwwehgfuiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    }
    ,

    {

      book_id: 3,
      book_details: "aW34FWydfawe",
      book_name: "wtfweaiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    },



    {

      book_id: 4,
      book_details: "aW34FWydfawe",
      book_name: "wtfweaiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    },


    {

      book_id: 1,
      book_details: "auydfawe",
      book_name: "euiwhgfuiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    }

    ,
    {

      book_id: 2,
      book_details: "eWFawe",
      book_name: "Efqwwehgfuiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    }
    ,

    {

      book_id: 3,
      book_details: "aW34FWydfawe",
      book_name: "wtfweaiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    },



    {

      book_id: 4,
      book_details: "aW34FWydfawe",
      book_name: "wtfweaiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    },

    {

      book_id: 1,
      book_details: "auydfawe",
      book_name: "euiwhgfuiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    }

    ,
    {

      book_id: 2,
      book_details: "eWFawe",
      book_name: "Efqwwehgfuiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    }
    ,

    {

      book_id: 3,
      book_details: "aW34FWydfawe",
      book_name: "wtfweaiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    },



    {

      book_id: 4,
      book_details: "aW34FWydfawe",
      book_name: "wtfweaiwa",
      book_quantity: 2,
      user_id: 1,
      category_id: 2
    },
  ];


  




}
