import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';

@Component({
  selector: 'app-loginhome',
  templateUrl: './loginhome.component.html',
  styleUrls: ['./loginhome.component.css']
})
export class LoginhomeComponent implements OnInit {

  showModal: boolean;


  constructor(private svc: RestService) { }










  // booksimages = [
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",


  // ];

  // electronicsimages = [
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",


  // ];
  img1: any;

  alluser: any = sessionStorage.getItem("ALLUSERS");


  alluser1 = [
    {
      userId: 2,
      name: "prasad",
      email: "onkar@123",
      password: "N/A",
      image: null,
      contact: {
        contactNo: 222222,
      },
      

    }
  ]
  //  alluser1=[
  //    {
  //     userId: 1,
  //     name: "onkar",
  //     email: "onkar@123",
  //     password: "N/A",
  //     image: null,
  //     contact:543663,
  //     contactNo: 123456789,
  //     __proto__: Object,
  //     address:"efgui0",
  //     addressId: 1,
  //     address: "pune",
  //     pinCode: 123456789,
  //     __proto__: Object
  //     book: Array(9)
  //     0: {bookId: 4, bookName: "digis", bookDetails: "very good book", bookQuantity: 2, suggestion: null}
  //     1: {bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null}
  //     2: {bookId: 6, bookName: "wgerg", bookDetails: "wefwe", bookQuantity: 1, suggestion: null}
  //     3: {bookId: 7, bookName: "ergwwr", bookDetails: "wefg", bookQuantity: 1, suggestion: null}
  //     4: {bookId: 8, bookName: "eqgewq", bookDetails: "eqg", bookQuantity: 1, suggestion: null}
  //     5: {bookId: 9, bookName: "gevewr", bookDetails: "ewgwer", bookQuantity: 1, suggestion: null}
  //     6: {bookId: 10, bookName: "book11", bookDetails: "bookdetails11", bookQuantity: 1, suggestion: null}
  //     7: {bookId: 11, bookName: "book11", bookDetails: "bookdetails11", bookQuantity: 1, suggestion: "please call in the evening"}
  //     8: {bookId: 13, bookName: "book11", bookDetails: "bookdetails11", bookQuantity: 1, suggestion: "please call in the evening"}
  //     length: 9
  //     __proto__: Array(0)
  //     electronic: Array(1)
  //     0: {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
  //     length: 1
  //     __proto__: Array(0)
  //     dob: "2020-01-10"
  //    }
  //  ]
  ngOnInit() {
  }



  show(image) {
    this.showModal = true; // Show-Hide Modal Check
    this.img1 = image;
  }
  //Bootstrap Modal Close event
  hide() {
    this.showModal = false;
  }


  getuser() {
    console.log(this.alluser);
  }


}


// userId: 1
// name: "onkar"
// email: "onkar@123"
// password: "N/A"
// image: null
// contact:
// contactNo: 123456789
// __proto__: Object
// address:
// addressId: 1
// address: "pune"
// pinCode: 123456789
// __proto__: Object
// book: Array(9)
// 0: {bookId: 4, bookName: "digis", bookDetails: "very good book", bookQuantity: 2, suggestion: null}
// 1: {bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null}
// 2: {bookId: 6, bookName: "wgerg", bookDetails: "wefwe", bookQuantity: 1, suggestion: null}
// 3: {bookId: 7, bookName: "ergwwr", bookDetails: "wefg", bookQuantity: 1, suggestion: null}
// 4: {bookId: 8, bookName: "eqgewq", bookDetails: "eqg", bookQuantity: 1, suggestion: null}
// 5: {bookId: 9, bookName: "gevewr", bookDetails: "ewgwer", bookQuantity: 1, suggestion: null}
// 6: {bookId: 10, bookName: "book11", bookDetails: "bookdetails11", bookQuantity: 1, suggestion: null}
// 7: {bookId: 11, bookName: "book11", bookDetails: "bookdetails11", bookQuantity: 1, suggestion: "please call in the evening"}
// 8: {bookId: 13, bookName: "book11", bookDetails: "bookdetails11", bookQuantity: 1, suggestion: "please call in the evening"}
// length: 9
// __proto__: Array(0)
// electronic: Array(1)
// 0: {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
// length: 1
// __proto__: Array(0)
// dob: "2020-01-10"