import { Component, OnInit } from '@angular/core';
import {RestService} from '../../../service/rest.service';
import {FormGroup} from '@angular/forms';
@Component({
  selector: 'app-donate-electronic',
  templateUrl: './donate-electronic.component.html',
  styleUrls: ['./donate-electronic.component.css']
})
export class DonateElectronicComponent implements OnInit {

  electronicForm=FormGroup;
  electronic:any;
  constructor(private svc:RestService) { }
  

  ngOnInit() {    
    
  }

}
