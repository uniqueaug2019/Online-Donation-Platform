import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-donate-book',
  templateUrl: './donate-book.component.html',
  styleUrls: ['./donate-book.component.css']
})
export class DonateBookComponent implements OnInit {
  bookForm: FormGroup;
  book: any;
  selectedFile: File;
  status: boolean=false;
  msg: string;
  path: any;
  constructor(private svc: RestService) { }

  ngOnInit() {

    this.bookForm = new FormGroup({
      bookName: new FormControl(),
      bookDetails: new FormControl(),
      bookQuantity: new FormControl(),
      specification:new FormControl(),
      image: new FormControl()
      // categoryName: new FormControl(),
    });

    
  }


  Submit() {
  
    this.book = {
      bookName: this.bookForm.get('bookName').value,
      bookDetails: this.bookForm.get('bookDetails').value,
      bookQuantity: this.bookForm.get('bookQuantity').value,
      categoryName:localStorage.getItem("category"),
      userId:sessionStorage.getItem("loggedInUserId"),
      specification:this.bookForm.get('specification'),
      image:this.bookForm.get('image')
    }
    console.log(this.book);
    this.donate(this.book);
   
  }


  donate(book) {

    console.log(book);

    console.log(book);
    this.svc.donate(book).then(response => {
      console.log(response);
this.status=true;
this.msg = "Book Donation successful";

   

    }).catch(error => {
      console.log(error);
      // this.msg = "Invalid";
      this.msg = "Book Donation unsuccessful";

    }
    )
  }



  
  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
    
    this.path=event.target.files;
  
    console.log("egfiueguek");
    console.log(this.path);
    console.log(this.selectedFile);
    
    
  }

}
