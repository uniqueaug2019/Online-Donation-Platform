import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service'
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {
  userLogin: FormGroup;
  submitted= false;
  resetmsg: string="";
  constructor(private svc: RestService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.userLogin = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
     
    })

  }
  get f() { return this.userLogin.controls; }
  onSubmit() {

    this.submitted = true;

     // stop here if form is invalid
     if (this.userLogin.invalid) {
      return;
    }
    console.log(this.userLogin.value);

    this.reset(this.userLogin.value);

  }
  
  reset(user) {

    console.log(user);
    this.svc.reset(user).then(response => {
      this.resetmsg=" PLEASE CHECK YOUR EMAIL"
      console.log(this.resetmsg);
      console.log(response);
   
      

    }).catch(error => {
      console.log(error);
       

    }
    )
  }
}
