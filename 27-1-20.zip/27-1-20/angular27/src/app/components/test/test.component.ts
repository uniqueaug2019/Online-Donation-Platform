import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  localUrl: any[];
  private base64textString: String = "";
  constructor(private svc: RestService) { }

  ngOnInit() {
  }

  handleFileSelect(evt) {

    var files = evt.target.files;
    var file = files[0];

    if (files && file) {
      var reader = new FileReader();

      reader.onload = this._handleReaderLoaded.bind(this);

      reader.readAsBinaryString(file);
    }
  }

  _handleReaderLoaded(readerEvt) {
    var binaryString = readerEvt.target.result;
    this.base64textString = btoa(binaryString);
    console.log("string format");
    // console.log(btoa(binaryString));
    console.log(this.base64textString);
    this.image(this.base64textString);

  }

  image(istring) {

    this.svc.image(istring).then(response => {


      console.log(response);



    }).catch(error => {
      console.log(error);


    }
    )



  }





  

  showPreviewImage(event: any) {
    console.log("ijrsgvhuirghuik");
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      console.log("ijrsgvhuirghuik");
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
        console.log(this.localUrl);
      }
      reader.readAsDataURL(event.target.files[0]);
    }
  }
}




