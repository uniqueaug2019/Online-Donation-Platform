package spring.donation.donation.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.daos.IElectronicsDao;
import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Category;
import spring.donation.donation.pojos.Electronics;
import spring.donation.donation.pojos.User;

@Service
public class ElectronicServiceImpl implements IElectronicService {
	@Autowired
	ICategoryDao catdao;
	
    @Autowired
    IUserDao userdao;
    
    @Autowired
    IElectronicsDao eledao;
    
	@Override
	public boolean insertElectronic(String electronicName, String electronicDetail, String electronicQuantity, String suggestion, String categoryName, MultipartFile image, String userId) {
		
		Category tempcat=null;
		boolean status = false;

		System.out.println("inside insert book");// just for checking flow		
		User user=userdao.getOne(Integer.parseInt(userId));		
		// first fetch category by categoryname
		List<Category> tb = catdao.findByCategoryName(categoryName);
		try {
			tempcat = tb.get(0);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Electronics el=new Electronics(electronicName,electronicDetail,Integer.parseInt(electronicQuantity),suggestion);
		try {
			if(image!=null)
			el.setImage(image.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		el.setElectronicUser(user);
		// add new book into books category
		tempcat.addElectronic(el);
		if (catdao.save(tempcat)!= null)// if record found it returns record
		{
			status = true;
		}
		return status;
	}

	@Override
	public void deleteElectronic(int electronicId) {
		System.out.println(electronicId);		
		eledao.deleteById(electronicId);		
	}

}
