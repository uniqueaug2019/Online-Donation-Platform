package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.service.IElectronicService;

@RestController
@CrossOrigin(allowedHeaders = "*", value = "*")
public class ElectronicController {

	@Autowired
	IElectronicService service;

	// add electronic product
	@RequestMapping(value = "/addelectromnic", method = RequestMethod.POST)
	public ResponseEntity<String> addElectronic(@RequestParam String electronicName,
			@RequestParam String electronicDetail, @RequestParam String electronicQuantity,
			@RequestParam String suggestion, @RequestParam String categoryName,
			@RequestParam(value = "image", required = false) MultipartFile image, @RequestParam String userId) {

		String msg = "Electronics Insertion Failed";
		if (service.insertElectronic(electronicName, electronicDetail, electronicQuantity, suggestion, categoryName,
				image, userId)) {
			msg = "Electronics Insertion Successfull";
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		}
		return new ResponseEntity<String>(msg, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// delete Electronics
	@RequestMapping(value = "/deleteelectronic/{electronicId}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteBook(@PathVariable String electronicId) throws Exception {
		System.out.println(electronicId);
		try {
			service.deleteElectronic(Integer.parseInt(electronicId));
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
