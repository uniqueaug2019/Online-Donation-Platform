package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import spring.donation.donation.service.UserServiceImpl;

@Controller
@RequestMapping("/reset/01010/email-reset-09/12334fadgh/retgsfdvcxhtrsdhfAHGD/AspassNfdgfds")
public class PasswordResetController {

 @Autowired
 UserServiceImpl service;
//get mapping for showing reset password page
	@GetMapping
	public String showUploadForm() {
		System.out.println("in show upload form ");
		return "reset";
	}

	
	@PostMapping
	public String processUploadForm(@RequestParam String password,String password1,String email,Model map) {
        map.addAttribute("msg","Your Email or Password Might Not Be Matching");
		System.out.println(password+password1+email);
		if(password.equals(password1))
		{
			if(service.ChangePassword(email,password))
			{
			return "reseted";
			}
		}				
		return "reset";
	}
}
