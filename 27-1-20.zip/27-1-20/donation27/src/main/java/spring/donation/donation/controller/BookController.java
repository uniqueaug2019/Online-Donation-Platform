package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.service.BookServiceImpl;

@RestController()
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BookController {
	@Autowired
	BookServiceImpl service;// auto inject bookservice object

	// add new book
	@RequestMapping(value = "/addbook", method = RequestMethod.POST)
	public ResponseEntity<String> addBook(@RequestParam String bookName, @RequestParam String bookDetails,
			@RequestParam String bookQuantity, @RequestParam String suggestion, @RequestParam String userId,
			@RequestParam(value = "image", required = false) MultipartFile image, @RequestParam String categoryName) {
		System.out.println("DONEEEEEEEE");
		String msg = "INSERTION FAILED";

		if (service.insertBook(bookName, bookDetails, bookQuantity, suggestion, userId, image, categoryName)) {
			msg = "INSERTION SUCCESSFULL";
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		}
		return new ResponseEntity<String>(msg, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// delete book
	@RequestMapping(value = "/deletebook/{bookId}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteBook(@PathVariable String bookId) throws Exception {
		System.out.println(bookId);
		try {
			service.deleteBook(Integer.parseInt(bookId));
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
