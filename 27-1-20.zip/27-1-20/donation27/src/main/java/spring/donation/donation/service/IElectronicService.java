package spring.donation.donation.service;

import org.springframework.web.multipart.MultipartFile;

public interface IElectronicService {
public boolean insertElectronic(String electronicName, String electronicDetail, String electronicQuantity, String suggestion, String categoryName, MultipartFile image, String userId);
public void deleteElectronic(int electronicId);
}
