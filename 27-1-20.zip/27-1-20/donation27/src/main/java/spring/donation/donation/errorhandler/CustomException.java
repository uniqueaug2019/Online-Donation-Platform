package spring.donation.donation.errorhandler;


@SuppressWarnings("serial")
public class CustomException extends Exception{
	
	public CustomException(String err) {
		super(err);
	}

}
