package spring.donation.donation.service;

import org.springframework.web.multipart.MultipartFile;

public interface IBookService {

	public boolean insertBook(String bookName, String bookDetails, String bookQuantity, String suggestion, String userId, MultipartFile image,String categoryName);
	
	public void deleteBook(int bookId) ;
	
}
