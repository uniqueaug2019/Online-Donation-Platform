package spring.donation.donation.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import spring.donation.donation.pojos.Electronics;

public interface IElectronicsDao extends JpaRepository<Electronics, Integer>{

}
