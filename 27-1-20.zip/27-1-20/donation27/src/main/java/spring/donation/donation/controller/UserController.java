package spring.donation.donation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import spring.donation.donation.pojos.User;
import spring.donation.donation.service.UserServiceImpl;

@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
public class UserController {
	@Autowired // service object injection
	UserServiceImpl service;
	//user login
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody String user) throws JsonMappingException, JsonProcessingException {
		System.out.println(user);
		User temp = service.authenticate(user);
		if (temp != null) {
			System.out.println("true");
			return new ResponseEntity<User>(temp, HttpStatus.OK);
		}
		System.out.println("false");
		return new ResponseEntity<String>("Auth Failed", HttpStatus.NOT_FOUND);
	}
	  	
	//register user
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<Void> Register(@RequestParam String name,@RequestParam String email,@RequestParam String password,@RequestParam String DOB,
			@RequestParam(value = "image",required = false) MultipartFile image,@RequestParam String add,@RequestParam String contactNo,
			@RequestParam String pinCode)  {		
		if(service.register(name,email,password,DOB,image,add,contactNo,pinCode))
		{
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
    
	//get all user
	@RequestMapping("/getalluser")
	public ResponseEntity<?> getAllUser() {
		List<User>ul=service.getAlluser();
		if(ul!=null)
		{
			return new ResponseEntity<List<User>>(ul,HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
  
	//for testing purpose
	@RequestMapping("/hello")
	public String hello() {
		return "<h2>HELLO</h2>";
	}
}
