package spring.donation.donation.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.IBookDao;
import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Books;
import spring.donation.donation.pojos.Category;
import spring.donation.donation.pojos.User;

@Service
public class BookServiceImpl implements IBookService {

	@Autowired
	ICategoryDao catdao;

	@Autowired
	IUserDao userdao;

	@Autowired
	IBookDao bookdao;

	@Override
	public boolean insertBook(String bookName, String bookDetails, String bookQuantity, String suggestion, String userId, MultipartFile image,String categoryName) {
		Category tempcat=null;
		boolean status = false;
		
		User user=userdao.getOne(Integer.parseInt(userId));		
		// first fetch category by categoryname
		List<Category> tb = catdao.findByCategoryName(categoryName);
		try {
			tempcat = tb.get(0);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Books bk=new Books(bookName, bookDetails, Integer.parseInt(bookQuantity),suggestion);
		try {
			if(image!=null)
			bk.setImage(image.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		bk.setBookuser(user);
		// add new book into books category
		tempcat.addBook(bk);
		if (catdao.save(tempcat)!= null)// if record found  return record
		{
			status = true;
		}
		return status;
	}

	@Override
	public void deleteBook(int bookId) {
		System.out.println(bookId);		
		bookdao.deleteById(bookId);	
	}
	
}
