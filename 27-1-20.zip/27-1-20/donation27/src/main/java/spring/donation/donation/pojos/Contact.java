package spring.donation.donation.pojos;

import javax.persistence.Column;
import javax.persistence.Embeddable;

//this class properties embedded into user and only single user table is created with extra column as contactNo 
@Embeddable
public class Contact {
@Column(name="ContactNo",unique = true)
private long contactNo;

public Contact() {
	System.out.println("inside contact CTOR");
}
public Contact(long contactNo) {
	super();
	this.contactNo = contactNo;
}
public long getContactNo() {
	return contactNo;
}
public void setContactNo(int contactNo) {
	this.contactNo = contactNo;
}
@Override
public String toString() {
	return "Contact [contactNo=" + contactNo + "]";
}


}


