import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service'
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userObj: any;
  status: boolean = false;
  userLogin: FormGroup;
  msg: string="";
  loggedInUser: string = null

  submitted= false;
  constructor(private svc: RestService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.userLogin = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    })


    this.loggedInUser = sessionStorage.getItem('loggedInUser');
    console.log("HELLO" + this.loggedInUser);
  }
  get f() { return this.userLogin.controls; }
  onSubmit() {

    this.submitted = true;

     // stop here if form is invalid
     if (this.userLogin.invalid) {
      return;
    }
    console.log(this.userLogin.value);

    this.login(this.userLogin.value);

  }



  login(user) {

    console.log(user);
    this.svc.login(user).then(response => {
      console.log(response);
      this.status = true;
      this.userObj = response;
      sessionStorage.setItem('loggedInUser', this.userObj.userId);
       this.msg = "Login successful";

    }).catch(error => {
      console.log(error);
       this.msg = "Invalid";

    }
    )
  }
  logout() {
    console.log("logout clicked");
    sessionStorage.removeItem('loggedInUser');
    this.router.navigate(["/"]).then(() => {
      window.location.reload();
    })
  }

}
