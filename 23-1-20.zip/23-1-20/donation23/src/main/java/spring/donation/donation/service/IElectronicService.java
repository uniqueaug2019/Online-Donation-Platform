package spring.donation.donation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface IElectronicService {
public boolean insertElectronic(String electronic)throws JsonMappingException, JsonProcessingException;
}
