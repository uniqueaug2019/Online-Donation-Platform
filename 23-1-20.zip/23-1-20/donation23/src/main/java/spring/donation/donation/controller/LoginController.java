package spring.donation.donation.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;


import spring.donation.donation.pojos.User;
import spring.donation.donation.service.UserServiceImpl;
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
public class LoginController {
	@Autowired//service object injection
	UserServiceImpl service;
	
    @RequestMapping(value="/login",method = RequestMethod.POST)
	public ResponseEntity<?>login(@RequestBody String user)throws JsonMappingException, JsonProcessingException
	{
    	System.out.println(user);
    	User temp=service.authenticate(user);
    	if(temp!=null)
    	{
       		System.out.println("true");
    		return new ResponseEntity<User>(temp,HttpStatus.OK);
 
    	}
    	System.out.println("false");
		return new ResponseEntity<String>("Auth Failed",HttpStatus.NOT_FOUND);
	}
    
    @RequestMapping(value = "/register",method=RequestMethod.POST)
    public boolean Register(@RequestBody String user)  throws JsonMappingException, JsonProcessingException
    {
  
    	System.out.println("user data is:"+user);
    	return service.register(user); 	
    }
    
    @RequestMapping("/hello")
    public String hello()
    {
    	return "<h2>HELLO</h2>";
    }
}
