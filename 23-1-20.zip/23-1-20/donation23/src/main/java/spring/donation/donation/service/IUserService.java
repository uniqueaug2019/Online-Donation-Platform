package spring.donation.donation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.util.JSONPObject;

import spring.donation.donation.pojos.User;

public interface IUserService {
public User authenticate(String user)throws JsonMappingException, JsonProcessingException;
public boolean register(String user)  throws JsonMappingException, JsonProcessingException;
}
