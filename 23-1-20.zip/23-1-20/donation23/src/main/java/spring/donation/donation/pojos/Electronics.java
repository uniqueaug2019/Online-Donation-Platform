package spring.donation.donation.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Electronics {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int electronicId;
private String electronicName;
private String electronicDetail;
private int electronicQuantity;

@ManyToOne
@JoinColumn(name="userId")
@JsonBackReference
private User electronicUser;

@ManyToOne
@JoinColumn(name="categoryId")
@JsonBackReference
private Category electronicCategory;

//default CTOR
public Electronics() {
	System.out.println("inside electronics CTOR");
}


//parameterized CTOR
public Electronics(String electronicName, String electronicDetail, int electronicQuantity, User electronicUser,
		Category electronicCategory) {
	super();
	this.electronicName = electronicName;
	this.electronicDetail = electronicDetail;
	this.electronicQuantity = electronicQuantity;
	this.electronicUser = electronicUser;
	this.electronicCategory = electronicCategory;
}

//another parameterized CTOR
public Electronics(String electronicName, String electronicDetail, int electronicQuantity) {
	super();
	this.electronicName = electronicName;
	this.electronicDetail = electronicDetail;
	this.electronicQuantity = electronicQuantity;

}


public int getElectronicId() {
	return electronicId;
}

public void setElectronicId(int electronicId) {
	this.electronicId = electronicId;
}

public String getElectronicName() {
	return electronicName;
}

public void setElectronicName(String electronicName) {
	this.electronicName = electronicName;
}

public String getElectronicDetail() {
	return electronicDetail;
}

public void setElectronicDetail(String electronicDetail) {
	this.electronicDetail = electronicDetail;
}

public int getElectronicQuantity() {
	return electronicQuantity;
}

public void setElectronicQuantity(int electronicQuantity) {
	this.electronicQuantity = electronicQuantity;
}

public User getElectronicUser() {
	return electronicUser;
}

public void setElectronicUser(User electronicUser) {
	this.electronicUser = electronicUser;
}

public Category getElectronicCategory() {
	return electronicCategory;
}

public void setElectronicCategory(Category electronicCategory) {
	this.electronicCategory = electronicCategory;
}


@Override
public String toString() {
	return "Electronics [electronicId=" + electronicId + ", electronicName=" + electronicName + ", electronicDetail="
			+ electronicDetail + ", electronicQuantity=" + electronicQuantity + ", electronicUser=" + electronicUser
			+ ", electronicCategory=" + electronicCategory + "]";
}

}
