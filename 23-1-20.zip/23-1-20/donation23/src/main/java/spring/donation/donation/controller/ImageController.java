package spring.donation.donation.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.http.HttpProperties.Encoding;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.IimageDao;
import spring.donation.donation.pojos.image;

@RestController
@CrossOrigin(value = "*" ,allowedHeaders = "*")
public class ImageController {
	
	@Autowired
	IimageDao dao;
	@RequestMapping(value = "/addimage",method = RequestMethod.POST)
	public String processUploadForm(@RequestParam("myfile") MultipartFile[] file) throws IOException {
		
		StringBuilder sb=new StringBuilder("Uploaded files : ");
		for(MultipartFile file1 : file)
		{
			sb.append(file1.getBytes());						
		}
	
		image img=new image(sb.toString().getBytes());
		image imgs=dao.save(img);	
		return "image is save";
		
	}
}
