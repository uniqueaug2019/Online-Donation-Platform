import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private svc:RestService) { }

  ngOnInit() {
  }


  register(user) {
    this.svc.register(user).then(response => {
      console.log(response);
     
    }).catch(error => {
      console.log(error);
      

    }
    )
  }
}
