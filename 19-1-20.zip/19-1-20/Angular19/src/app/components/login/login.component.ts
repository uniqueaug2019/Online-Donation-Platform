import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userObj: any;
  status: boolean = false;
  constructor(private svc: RestService,private router:Router) { }
  msg: string;
  loggedInUser: string = null

  ngOnInit() {
    this.loggedInUser = localStorage.getItem('loggedInUser');
    console.log("HELLO" + this.loggedInUser);
  }

  login(user) {
    this.svc.login(user).then(response => {
      console.log(response);
      this.status = true;
      this.userObj = response;
      localStorage.setItem('loggedInUser', this.userObj.email);
      // this.msg = "Login successful";

    }).catch(error => {
      console.log(error);
      // this.msg = "Invalid";

    }
    )
  }
  logout(){
    console.log("logout clicked");
    localStorage.removeItem('loggedInUser');
    this.router.navigate(["/"]).then(()=>{
      window.location.reload();
    })
  }

}
