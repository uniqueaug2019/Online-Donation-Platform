import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class RestService {

  url:string="http://192.168.76.217:8080/"
  constructor(private http:HttpClient) { }

  login(user){
    return this.http.post(this.url+"login",user).toPromise();
  }

  register(user){
    return this.http.post(this.url+"register",user).toPromise();
  }
}
