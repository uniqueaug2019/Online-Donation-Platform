package spring.donation.donation.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;



@Entity
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto increment id
	private int addressId;//primary key
	private String address; 
	private int pinCode;
	
	@OneToOne
	@JoinColumn(name="userId")
	private User user;

	public Address() {
		System.out.println("in Address CTOR");
	}
    
	public Address( String address, int pinCode) {
		super();
		this.address = address;
		this.pinCode = pinCode;

	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	

	

}
