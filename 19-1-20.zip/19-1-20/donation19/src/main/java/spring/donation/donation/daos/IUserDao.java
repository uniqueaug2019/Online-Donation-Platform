package spring.donation.donation.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import spring.donation.donation.pojos.Address;
import spring.donation.donation.pojos.User;

@Repository
public interface IUserDao extends JpaRepository<User,String>{
	 @Query("select u from User u where u.email=:email and u.password=:password  ")
	    List<User> findByEmailPassord(@Param("email")String email,@Param("password")String password);
	
//jpa repository auto provides CRUD operations
}
