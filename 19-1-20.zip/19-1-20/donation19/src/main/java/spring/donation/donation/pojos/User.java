package spring.donation.donation.pojos;

import java.sql.Blob;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;



@Entity
public class User {
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto increment id
	private int userId;
	private String name;
	private String email;
	private String password;
	private Date DOB;
	private Blob image;
	
	@Embedded
	private Contact contact=new Contact();	
	
	@OneToOne(mappedBy = "user",cascade = CascadeType.ALL)
	private Address address;
	
	public User() {
		System.out.println("Inside user CTOR");
	}
    //{"name":"onkar","email":"onk@123","password":"onk#123","dOB":"2019-12-12","contactNo":0978798897,"add":"pune","pinCode":122122}
	public User( String name, String email, String password, String dOB,/*Blob image,*/Contact contact,Address address) {
		super();
	    this.address=address;
	    this.contact=contact;
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.password = password;
		DOB = Date.valueOf(dOB);
		//this.image = image;
		/*
		 * this.contact.setContactNo(contactNo); this.address.setAddress(add);
		 * this.address.setPinCode(pinCode);
		 */

	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public Blob getImage() {
		return image;
	}

	public void setImage(Blob image) {
		this.image = image;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", email=" + email + ", password=" + password + ", DOB="
				+ DOB + ", image=" + image + ", contact=" + contact + ", address=" + address + "]";
	}
	
	
 
}
