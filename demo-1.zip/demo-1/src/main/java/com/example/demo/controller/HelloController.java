package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/email")
public class HelloController {
	
	@Autowired
	public JavaMailSender javaMailSender;
	
	@GetMapping(value="/sendEmail")
	public String sendmail() {
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo("pradnyakhot96@gmail.com");
		message.setSubject("SpringBootApplication");
		message.setText("Hi,How are you");
		
		javaMailSender.send(message);
		return"Succesfully send email";
	}

}
