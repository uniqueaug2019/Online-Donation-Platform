import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'

import { ReactiveFormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { FormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './components/register/register.component';
import { BuyproductsComponent } from './components/buyproducts/buyproducts.component';
import { DonateproductsComponent } from './components/donateproducts/donateproducts.component';
import { HomeComponent } from './components/home/home.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { DonateBookComponent } from './components/donateproducts/donate-book/donate-book.component';
import { DonateElectronicComponent } from './components/donateproducts/donate-electronic/donate-electronic.component';
import { TestComponent } from './components/test/test.component';
import { CoroComponent } from './components/coro/coro.component';


import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BlurtestComponent } from './components/blurtest/blurtest.component';  






const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login/buy', component: BuyproductsComponent },
  { path: 'login/donate', component: DonateproductsComponent },
  { path: 'home', component: HomeComponent},
  { path: 'aboutus', component: AboutusComponent},
  { path: 'login/donate/books', component:DonateBookComponent},
  { path: 'login/donate/electronics', component: DonateElectronicComponent },
  { path: 'test', component: TestComponent },


]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    BuyproductsComponent,
    DonateproductsComponent,
    HomeComponent,
    AboutusComponent,
    DonateBookComponent,
    DonateElectronicComponent,
    TestComponent,
    CoroComponent,
    BlurtestComponent
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,NgbModule 
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
