import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  showModal: boolean;
  constructor() { }

  images=[
"../assets/images/mrmercides.jfif",
"../assets/images/sherlockholmes.jfif",
"../assets/images/moana.jfif",
"../assets/images/studysmart.jfif",
"../assets/images/gobletoffire.jfif",
"../assets/images/encounters.jfif",
"../assets/images/dune.jfif",
"../assets/images/completecollection.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/sherlockholmes.jfif",
"../assets/images/moana.jfif",
"../assets/images/studysmart.jfif",
"../assets/images/gobletoffire.jfif",
"../assets/images/encounters.jfif",
"../assets/images/dune.jfif",
"../assets/images/completecollection.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/sherlockholmes.jfif",
"../assets/images/moana.jfif",
"../assets/images/studysmart.jfif",
"../assets/images/gobletoffire.jfif",
"../assets/images/encounters.jfif",
"../assets/images/dune.jfif",
"../assets/images/completecollection.jfif",

    
  ];
img1:any;
  ngOnInit() {
  }
  show(image)
  {
    this.showModal = true; // Show-Hide Modal Check
    this.img1=image;
  }
  //Bootstrap Modal Close event
  hide()
  {
    this.showModal = false;
  }



}
