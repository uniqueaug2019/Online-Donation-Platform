import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blurtest',
  templateUrl: './blurtest.component.html',
  styleUrls: ['./blurtest.component.css']
})
export class BlurtestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
