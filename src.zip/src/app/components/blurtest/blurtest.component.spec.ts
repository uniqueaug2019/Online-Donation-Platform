import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlurtestComponent } from './blurtest.component';

describe('BlurtestComponent', () => {
  let component: BlurtestComponent;
  let fixture: ComponentFixture<BlurtestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlurtestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlurtestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
