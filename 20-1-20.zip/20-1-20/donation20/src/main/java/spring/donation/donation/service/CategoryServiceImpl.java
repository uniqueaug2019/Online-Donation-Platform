package spring.donation.donation.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.pojos.Books;
import spring.donation.donation.pojos.Category;

@Service
public class CategoryServiceImpl implements ICategoryService {
	@Autowired
	ICategoryDao dao;

	@Override
	public boolean InsertBook(String book) throws JsonMappingException, JsonProcessingException {
		Category tempcat=null;
		boolean status = false;
		System.out.println("inside insert book");// just for checking flow
		System.out.println(book);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonNode = mapper.readTree(book);
		// extracting data from jsonobject
		String bookName = jsonNode.get("bookName").asText();
		String bookDetails = jsonNode.get("bookDetails").asText();
		int bookQuantity = jsonNode.get("bookQuantity").asInt();
		String categoryName = jsonNode.get("categoryName").asText();
		
		//first fetch category by categoryname
		List<Category> tb = dao.findByCategoryName(categoryName);
		try {
		 tempcat = tb.get(0);
		}catch(Exception e)
		{
		System.out.println(e);
		}
		
		//add new book into books category
		tempcat.addBook(new Books(bookName, bookDetails, bookQuantity));
		 if(dao.save(tempcat)!=null)//if record found it returns record
		 {
			 status=true;
		 }	 
		 return status;		
	}
}
