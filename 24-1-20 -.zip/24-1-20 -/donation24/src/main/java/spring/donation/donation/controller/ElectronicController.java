package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import spring.donation.donation.service.IElectronicService;

@RestController
@CrossOrigin(allowedHeaders = "*",value = "*")
public class ElectronicController {

	@Autowired
	IElectronicService service;
	@RequestMapping(value = "/addelectromnic",method = RequestMethod.POST)
	public String addElectronic(@RequestBody String electronic)throws JsonMappingException, JsonProcessingException
	{
		System.out.println("inside electronicscontroller");
		String res="Electronics Insertion Failed";
		if(service.insertElectronic(electronic))
		{
			res="Electronics Insertion Successfull";
		}				
		return res;		
	}
}
