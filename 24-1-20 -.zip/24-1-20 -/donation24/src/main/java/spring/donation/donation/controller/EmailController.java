package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value="/email")
public class EmailController {
	
	@Autowired
	public JavaMailSender javaMailSender;
	
	@RequestMapping(value="/sendEmail" ,method = RequestMethod.POST)
	public String sendmail(@RequestBody String emailstr) throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper=new ObjectMapper();
		JsonNode node=mapper.readTree(emailstr);
		
		String email=node.get("email").asText();
		
		final String  path="http://192.168.76.217:8080/reset/01010/email-reset-09/12334fadgh/retgsfdvcxhtrsdhfAHGD/AspassNfdgfds";
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo(email);
		message.setSubject("Reset Password");
		message.setText("Reset Your Helping Wall Password By Clicking on Following Link below :"+"<h3>"+path+"</h3>");		
		javaMailSender.send(message);
		return"Succesfully send email";
	}
}
