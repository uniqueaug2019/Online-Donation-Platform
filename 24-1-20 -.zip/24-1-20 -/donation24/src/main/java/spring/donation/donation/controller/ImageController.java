package spring.donation.donation.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.http.HttpProperties.Encoding;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.IimageDao;
import spring.donation.donation.pojos.image;

@RestController
@CrossOrigin(value = "*" ,allowedHeaders = "*")
public class ImageController {
	
	@Autowired
	IimageDao dao;
	@RequestMapping(value = "/addimage")
	public String processUploadForm(@RequestBody MultipartFile file) throws IOException {
		
		image img=new image(file.getOriginalFilename(),file.getContentType(),file.getBytes());
		System.out.println(img);
		image imgs=dao.save(img);	
		return "image is save";
		
	}
}
