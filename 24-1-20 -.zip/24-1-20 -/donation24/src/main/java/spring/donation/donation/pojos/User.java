package spring.donation.donation.pojos;

import java.sql.Blob;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerator;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.databind.ObjectMapper;

/*
@JsonIdentityInfo(
generator = ObjectIdGenerators.PropertyGenerator.class,
property = "id")*/
@Entity

public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment id
	private int userId;
	private String name;
    @Column(unique = true)
	private String email;
	private String password;
	private Date DOB;
	private Blob image;

	@Embedded
	private Contact contact = new Contact();

	@JsonManagedReference // it will solve problem of circular dependency which is generated during
							// serialization of object
	// "com.fasterxml.jackson.databind.ser.BeanSerializer.serialize",@jsonnreference
	// added in child and
	// @jsonmanagedreference annotations are added in parent to solve this problem
	@OneToOne(mappedBy = "addressuser", cascade = CascadeType.ALL)
	private Address address = new Address();

	@JsonManagedReference
	@OneToMany(mappedBy = "bookuser", cascade = CascadeType.ALL)
	private List<Books> book = new ArrayList<>();

	@JsonManagedReference
	@OneToMany(mappedBy = "electronicUser", cascade = CascadeType.ALL)
	List<Electronics> electronic = new ArrayList<>();

	public User() {
		System.out.println("Inside user CTOR");
	}

	public User(String name, String email, String password, String dOB, /* Blob image, */Contact contact,
			Address address) {
		super();
		this.address = address;
		this.contact = contact;
		this.name = name;
		this.email = email;
		this.password = password;
		DOB = Date.valueOf(dOB);

	}

	public User(String name, String email, String password, String dOB, /* Blob image, */Contact contact) {
		super();
		this.contact = contact;
		this.name = name;
		this.email = email;
		this.password = password;
		DOB = Date.valueOf(dOB);

	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public Blob getImage() {
		return image;
	}

	public void setImage(Blob image) {
		this.image = image;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Books> getBook() {
		return book;
	}

	public void setBook(List<Books> book) {
		this.book = book;
	}

	// helper function for adding address
	public void addAddress(Address a) {
		address = a;
		a.setAddressuser(this);
	}

	// helper function for adding book
	public void addBook(Books b) {
		book.add(b);
		b.setBookuser(this);
	}
	
	//helper function for adding electronic
	public void addElectronic(Electronics e)
	{
		electronic.add(e);
		e.setElectronicUser(this);		
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", email=" + email + ", password=" + password + ", DOB="
				+ DOB + ", image=" + image + ", contact=" + contact + ", address=" + address + ", book=" + book + "]";
	}

}
