package spring.donation.donation.controller;



import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;


import spring.donation.donation.pojos.User;
import spring.donation.donation.service.UserServiceImpl;
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
public class UserController {
	@Autowired//service object injection
	UserServiceImpl service;
	
    @RequestMapping(value="/login",method = RequestMethod.POST)
	public ResponseEntity<?>login(@RequestBody String user)throws JsonMappingException, JsonProcessingException
	{
    	System.out.println(user);
    	User temp=service.authenticate(user);
    	if(temp!=null)
    	{
       		System.out.println("true");
    		return new ResponseEntity<User>(temp,HttpStatus.OK);
 
    	}
    	System.out.println("false");
		return new ResponseEntity<String>("Auth Failed",HttpStatus.NOT_FOUND);
	}
    
    @RequestMapping(value = "/register",method=RequestMethod.POST)
    public boolean Register(@RequestBody String user)  throws JsonMappingException, JsonProcessingException
    {
  
    	System.out.println("user data is:"+user);
    	return service.register(user); 	
    }
    
   
    
    @RequestMapping("/hello")
    public String hello()
    {
    	return "<h2>HELLO</h2>";
    }
}
