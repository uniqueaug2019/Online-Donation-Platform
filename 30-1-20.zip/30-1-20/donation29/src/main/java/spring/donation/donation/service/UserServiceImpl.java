package spring.donation.donation.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Address;
import spring.donation.donation.pojos.Contact;
import spring.donation.donation.pojos.User;

@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	IUserDao dao;

	@Override
	public User authenticate(String user) {
		System.out.println("in user authenticate");
		ObjectMapper mapper = new ObjectMapper();
		// convert to json object
		JsonNode jsonNode = null;
		User tempuser = null;

		try {
			jsonNode = mapper.readTree(user);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}
		String email = jsonNode.get("email").asText();
		String password = jsonNode.get("password").asText();
		try {
			List<User> t = dao.findByEmailAndPassword(email, password);
			// get user form 0th index as it is stored in 0th index
			tempuser = t.get(0);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("user is null");
		}
		System.out.println("advgdfsbv");
		// tempuser.setPassword("N/A");
		return tempuser;
	}

	// register new user
	@Override
	public boolean register(String name, String email, String password, String dOB, MultipartFile image, String add,
			String contactNo, String pinCode) {
		boolean status = false;
		String userimg = "iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAWlBMVE"
				+ "X///9+fn5zc3OCgoL09PR5eXl7e3t2dnb7+/vs7OxycnKenp65ubm9vb3p6emNjY2np6fLy8ve3t6zs7"
				+ "Ph4eGtra2Tk5OYmJjS0tLIyMjCwsKVlZXX19epqakmQ2u1AAAI0ElEQVR4nO1d2bqiMAw+FNqyyqaoqO//mgOjdg"
				+ "FUaKNEv/43czHf6Ulo9iY5f38ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4jBNWhPGZp1paHcxSuTQ0wNm2Re4R3oB26"
				+ "fwjzk7RamywghGXBCGXM08EY5eSURWuTZ41zQfmQOYVNyvPjNwtsmHlP2LsxyUmxWZtQQwQppS/YuzFJkq/kMeXz+L"
				+ "vyuA/WpncpKp/P5u/KY7o2yYsQJmQRfz24v12b7PnYjnzD7aJY7w7Zo/+Ns7UJn4tsfIGMdW7eT3Z1ltW7Yu/3vn/M"
				+ "Jz99h+fYjzSQknx30E1JcK5zMmKSsS8wqmE+MKGM+9m0oQzafGRvOfpQLvD1e2Fx8syAbOohj+TwMVqNEOhWhPHiVe"
				+ "AZpkznkRw/QqkhQv0GSTMnsA7rWPupGPMtagwyby6pm1wzTgSvLp5UBvl+gemvY83cYM2pdupNkGXuu1IVmPlvotASZ"
				+ "9XRL5Y0zQjT5C0UWiJQbtDIczeKTUVpUHN5B8wzyoX2Kov4VPGoXCE1JE/9SA0sefYIFQa5aRqkulNegtJnj0JKmEXc"
				+ "pekyrjxjI+0o3Vmco9hjWoNRB4FEiBfLrQ7aSVngmC4xkiEJsczwpCpSTJWbQpJlI6M9KkVO8VxipEQz1lRJgad46ja"
				+ "ZUB4AGx+Iz4UoPPWliQc4TYo8wVJf3HJQuZIyb63UUJAWHsY2KJoIcRwApIwWIOedhUwgqbxJqYIiCJtLlFkFhJ3pIc"
				+ "QeSYYh1IZBGYZKmi4UTl+oIYcqA4a4FFFmPBzslbO5iwXHUM2Q3hAuBEnviogihSrvHDK4AtlBnLkHO9Mc8nvDmfaNz"
				+ "PXBzjSHCCMBKyvS1MRgZ5pDOAtIuydieYLAXewFh4CZgMj0CYIuFGHZbesXKkTlFENlOH/H55YOEcHD/ls+NyoOf19Kf"
				+ "9/S/L63+H2P/5aoTVYUwc40x+HnI+93ZE8Zquzp9zPgN1Qx/nBVMaQx/dlKVAmertbIqonwFWHh77G8rwmCgKr6FTI1/"
				+ "PvbyUd8ELUp0L3MbKWYtgDHBfhe14BfSOVjHZoXUvWV295Do3zlVluZrDVRaiGIzAMBsNtki7LbBLJjKMf2PHoDWNdXK"
				+ "gUeVdeX1rl3sTinQtu5p3bcWXRfhkqXMLLuS402c1VUmoThUjEolGrzq2GRU2n0RpJVaGjk9zfsZC/UTmoEleAhAlWHPA"
				+ "MCE4VBlNMI2kQJW14AV8ctcE6UdKm5OhW0sD4cqSMziALSAdSREI8sSYdLbfcCRiW8IVfppLPHzwN9uB3yiQca+oQlI8U"
				+ "sm9rqE8/x+d1k2iDw9ClZUr/ksRxsXyDYhmUGGE46U757FuGEx+F2CeyTzn+61b/eY95OX2R4TshotB1Jde0pksGtdGTz"
				+ "vD4PAulNexrv5mEegmf7GWjJaCFEvzLJb4o6O5bHNt31ayOmtkYsGR1eFRt/cjVNv/jj/zKs6d0fbOHo8KoIk3iKh6f4qu"
				+ "0tHbZLN/DwL7rAG9qhnXzGX5wg6CpZjozNu8cu9sEbiL5AO2+b2dfy16O6PN9IR5ryWzzEQ4SHy5T367cKsn371denICo7"
				+ "Jx/fFkP+3wxJm6L9Lu8wA8H2XLZZnbbHQ/WVlrPTuTQHeNIMiibDeLvRMemVjVLbIlnGew3lSYnqmre1T+4Wk+c26YFYRtg"
				+ "5kbxGkmhEma8tXmPxzvTzB1o427kSH8EG17IZr7ikNDXxccFu7Dl7fwlO8xKaurhs0p1Tni69x6CejmO737D4LChElycbSik"
				+ "vlhjEKnl+1hoaGexe5A59fWaeFm06TX4evrL447FrOGfDbL8H+aVr26bj5YmT38vYfhmhnN4QPL6Izh6y5PgghAmqdk+n6jWT"
				+ "RQ76wRw5aKbyvs627yftTu/AvaRuD9UmCsIwDKJNVWZ1wiarUV7vUnM+ddLH6hztxG/v2Eu3/XrAR9t1r0UoQjglhPzfz/pI8ygt"
				+ "+xDpFI9/TSeqH+AvyEcX2KXyIvw4LKzPjPjj9xaM8JiPbRl9f0G1Gn17ShKtTn18ndc/5k+3J1E68rfs3b3tWTygidPx20vpm/FI+"
				+ "dhelvnQkSx6l1yMYcGee9Nb8c+nBYW2Kxj3p583qtOAR+q/z28MHl2e2e+o9pZUE7t06fGTTDWwX0Z9EHMQ5sO3wefxdZdTPXAHQ/Z"
				+ "ocnh+1Fl/JmD0LfZm8DI4Kw/cpg154hh6Vxn7lxfs/cdgE+87HuEGD9jzu1urLMkpub7H3I5gtzca/1Qf5upUNNjEC+/8G5VB6i/T"
				+ "hHBzaOtL0uQ+jbnn56eizsrtQoOhb+Kl0OYmMW4kgYO+idess+whtBXB8Vppd6Due4dtKzqoAsJX7AZRd/ZTQEmKbFcEw0HtXwTsS"
				+ "1EdoekGXShoLELRoirh+jsOlMgRShWVLnUUczpKfyCHGVhQZBRHw5JKEIScKmusOY5ZMmUICWKaPUTYXa50IwNIVa1IPZrnIDndYW"
				+ "9slE3kOGbjr5ATj9ZzGan8WnYDTbCQ00O2ZClaiGEXjoQcJSN2QaScDgWa04ZCAHWJUt4xLPtRoUwL24RZyg5kZLNyilO0Ik1O2uPx"
				+ "FHdcQKb2pRbiG9OR4bJFwipW/aD8E0yicmTx+YUgoBxEOgDsVJE7RlCNVd8QitKKcU4n96Sun/dOQezCM17y0gpDg1FI1f2+pk5fRE"
				+ "bonOEVyg4uwy5c6QyRTpOJZN9wnk+GfhiWF05B2HrDxK6yFvN3Qyqi2R4HYWiQqqGyg8vwDuTaTrQzj3LfktGP2+rxB2C5w1hENPjy"
				+ "ijsSq0sI5coZcMqgIKpIRv4ssFTjT0AYU6MGepHfI8wN7xB/c8fI3IufBltpCQ95CyZ1Mrnptg4DpLCTM7lShxGskCSavNAc7dooPw"
				+ "ujR6N2ae/dmjCy99nPc5h+E4dGVYiv4vD375Cdfp5DE3/4PRwyxrhJTJN6/pcgb5ICbZLu4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4"
				+ "ODg4ACGf/EkXnk8uPn/AAAAAElFTkSuQmCC";
		// create user
		User u = new User(name, email, password, dOB, new Contact(contactNo));
		try {
			// set Image
			if (image != null)
				u.setImage(image.getBytes());
			else
				u.setImage(userimg.getBytes());

		} catch (IOException e) {
			e.printStackTrace();
		}
		// create address
		Address a = new Address(add, Integer.parseInt(pinCode));
		// add address using helper function
		u.addAddress(a);
		// save into db
		User user = dao.save(u);
		if (user != null)
			status = true;
		return status;
	}

	@Override
	public boolean ChangePassword(String email, String password) {
		boolean status = false;
		User u = null;

		try {
			// get user by email password directly can't be changed else generate illegal
			// state exception
			// fetch pojo to change password
			List<User> ul = dao.findByUserEmail(email);
			// Available at 0th location
			u = ul.get(0);
			// setting password
			u.setPassword(password);
			// persist the pojo
			u = dao.save(u);
		} catch (Exception e) {
			System.out.println("errro in db");
		}
		if (u != null) {
			status = true;
		}
		return status;
	}

	@Override
	public List<User> getAlluser() {
		// fetch all users
		List<User> userlist = dao.findAll();
		// set password all users password to N/A
		for (User u : userlist) {
			u.setPassword("N/A");
		}
		return userlist;
	}

	@Override
	public void deleteUser(int userId) {
		System.out.println(userId);
		dao.deleteById(userId);
	}

	@Override
	public User getUserByEmail(String useremail) {
		System.out.println("in user email");
		User tempuser = null;
		try {
			List<User> t = dao.findByUserEmail(useremail);
			// get user form 0th index as it is stored in 0th index
			tempuser = t.get(0);
		} catch (Exception e) {
			System.out.println("user is null");
		}
		// tempuser.setPassword("N/A");
		return tempuser;
	}

	@Override
	public User updateUserDetails(MultipartFile image, String contact, String userId) {
		User user = null;
		Optional<User> ouser = dao.findById(Integer.parseInt(userId));
		try {
			user = ouser.get();
			if (image != null)
				user.setImage(image.getBytes());
			if (contact != null)
				user.setContact(new Contact(contact));
			dao.save(user);
		} catch (Exception e) {
			System.out.println("user is null");
		}
		return user;
	}

}