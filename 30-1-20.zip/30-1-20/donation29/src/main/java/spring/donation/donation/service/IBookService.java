package spring.donation.donation.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.pojos.Book;

public interface IBookService {

	public boolean insertBook(String bookName, String bookDetails, String bookQuantity, String suggestion, String userId, MultipartFile image,String categoryName);
	
	public void deleteBook(int bookId) ;
	public List<Book>getAllBooks();
	public List<Book>searchBook(String name);
	
}
