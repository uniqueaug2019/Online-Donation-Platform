package spring.donation.donation.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.pojos.Electronic;

public interface IElectronicService {
public boolean insertElectronic(String electronicName, String electronicDetail, String electronicQuantity, String suggestion, String categoryName, MultipartFile image, String userId);
public void deleteElectronic(int electronicId);
public List<Electronic>getAllElectronics();
}
