package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value="/email")
@CrossOrigin(value = "*",allowedHeaders = "*")
public class EmailController {
	
	@Autowired
	public JavaMailSender javaMailSender;
	
	@RequestMapping(value="/sendEmail" ,method = RequestMethod.POST)
	public ResponseEntity<Void> sendmail(@RequestBody String emailstr){
		System.out.println(emailstr);
		ObjectMapper mapper=new ObjectMapper();
		JsonNode node = null;
		try {
			node = mapper.readTree(emailstr);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}	
		String email=node.get("email").asText(); 		
		final String  path="http://192.168.43.103:8090/reset/01010/email-reset-09/12334fadgh/retgsfdvcxhtrsdhfAHGD/AspassNfdgfds";
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo(email);
		message.setSubject("Reset Password");
		message.setText("Reset Your Helping Wall Password By Clicking on Following Link  : "+path);	
		try {
		javaMailSender.send(message);
		}catch(Exception e)
		{
			return new ResponseEntity<Void>(HttpStatus.REQUEST_TIMEOUT);
		}
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	/*
	 * @RequestMapping(value="/sendProductUpdateMail" ,method = RequestMethod.POST)
	 * public String sendProductUpdateMail(@RequestBody String emailstr) {
	 * 
	 * ObjectMapper mapper=new ObjectMapper(); JsonNode node = null; try { node =
	 * mapper.readTree(emailstr); } catch (JsonMappingException e) {
	 * System.out.println("JsonMappingException Occured"); } catch
	 * (JsonProcessingException e) {
	 * System.out.println("JsonProcessingException Occured"); } String
	 * email=node.get("email").asText(); String productName
	 * =node.get("productName").asText(); SimpleMailMessage message=new
	 * SimpleMailMessage(); message.setTo(email);
	 * message.setSubject("Donated Product Update");
	 * message.setText("Thank you for donating "
	 * +productName+"\n We are Happy we have Donator like YOU:)"); try {
	 * javaMailSender.send(message); }catch(Exception e) { e.printStackTrace(); }
	 * return "Product update Mail Succesfully  sended"; }
	 */
}
