package spring.donation.donation.controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.User;
import spring.donation.donation.service.UserServiceImpl;

@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
public class UserController {
	@Autowired // service object injection
	UserServiceImpl service;
	@Autowired
	IUserDao userdao;
	@Autowired
	EntityManager em;

	// user login
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody String user) throws JsonMappingException, JsonProcessingException {
		System.out.println("user details email pass:" + user);
		User temp = service.authenticate(user);
		if (temp != null) {
			System.out.println("true");
			return new ResponseEntity<User>(temp, HttpStatus.OK);
		}
		System.out.println("false");
		return new ResponseEntity<String>("Auth Failed", HttpStatus.NOT_FOUND);
	}
	
	//get user by email
	@RequestMapping(value = "/getuserbyemail", method = RequestMethod.POST)
	public ResponseEntity<?> getUserByEmail(@RequestParam String email) {
		System.out.println("user email :" + email);
		User temp = service.getUserByEmail(email);
		if (temp != null) {
			System.out.println("true");
			return new ResponseEntity<User>(temp, HttpStatus.OK);
		}
		System.out.println("false");
		return new ResponseEntity<String>("Auth Failed", HttpStatus.NOT_FOUND);
	}

	// register user
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<Void> Register(@RequestParam String name, @RequestParam String email,
			@RequestParam String password, @RequestParam String DOB,
			@RequestParam(value = "image", required = false) MultipartFile image, @RequestParam String add,
			@RequestParam String contactNo, @RequestParam String pinCode) {
		if (service.register(name, email, password, DOB, image, add, contactNo, pinCode)) {
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	// get all user
	@RequestMapping("/getalluser")
	public ResponseEntity<?> getAllUser() {
		List<User> ul = service.getAlluser();
		if (ul != null) {
			return new ResponseEntity<List<User>>(ul, HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	


	// delete user by id
	@RequestMapping(value = "/deleteuser/{userId}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteBook(@PathVariable String userId) throws Exception {
		System.out.println(userId);
		try {
			if(userId!=null)
			service.deleteUser(Integer.parseInt(userId));
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	// get book user by id
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getbookuser/{bookId}", method = RequestMethod.GET)
	public List<User> getbookuser(@PathVariable String bookId) {
		javax.persistence.Query q = em.createNativeQuery(
				"select  u.name,u.image, u.contact_no,a.address from user u inner join  book b inner join address a on b.user_id=u.user_id and a.user_id=u.user_Id where b.book_id=:id");
		q.setParameter("id", Integer.parseInt(bookId));
		return q.getResultList();
	}

	// get electronic user by id
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getelectronicuser/{electronicId}", method = RequestMethod.GET)
	public List<User> getelectronicuser(@PathVariable String electronicId) {
		javax.persistence.Query q = em.createNativeQuery(
				"select  u.name,u.image, u.contact_no,a.address from user u inner join  electronic e inner join address a on e.user_id=u.user_id and a.user_id=u.user_Id where e.electronic_id=:id");
		q.setParameter("id", Integer.parseInt(electronicId));
		return q.getResultList();
	}
	
   //update user details
	@RequestMapping(value = "/updateuserdetails",method = RequestMethod.POST)
	public ResponseEntity<?>updateUserDetails(@RequestParam(required = false, value = "image")MultipartFile image,@RequestParam(required = false)String contact,@RequestParam String userId)
	{
		User u=service.updateUserDetails(image, contact,userId);
		if(u!=null)
		{
			return new ResponseEntity<User>(u,HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	}
		
	// for testing purpose
	@RequestMapping("/hello")
	public String hello() {
		return "<h2>HELLO</h2>";
	}
}
