package spring.donation.donation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.IElectronicsDao;
import spring.donation.donation.pojos.Electronic;
import spring.donation.donation.service.IElectronicService;

@RestController
@CrossOrigin(allowedHeaders = "*", value = "*")
public class ElectronicController {

	@Autowired
	IElectronicService service;
	@Autowired
	IElectronicsDao eledao;

	// add electronic product
	@RequestMapping(value = "/addelectronic", method = RequestMethod.POST)
	public ResponseEntity<Void> addElectronic(@RequestParam String electronicName,
			@RequestParam String electronicDetails, @RequestParam String electronicQuantity,
			@RequestParam String suggestion, @RequestParam String categoryName,
			@RequestParam(value = "image", required = false) MultipartFile image, @RequestParam String userId) {
		System.out.println(electronicName + " " + electronicDetails + " " + electronicQuantity + " " + suggestion + " "
				+ categoryName + " " + userId);		
		if (service.insertElectronic(electronicName, electronicDetails, electronicQuantity, suggestion, categoryName,
				image, userId)) {
			return new ResponseEntity<Void>( HttpStatus.OK);
		}
		return new ResponseEntity<Void>( HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// delete Electronics
	@RequestMapping(value = "/deleteelectronic/{electronicId}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteBook(@PathVariable String electronicId) throws Exception {
		System.out.println(electronicId);
		try {
			service.deleteElectronic(Integer.parseInt(electronicId));
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	// get all electronics product
	@RequestMapping(value = "/getallelectronics", method = RequestMethod.GET)
	public ResponseEntity<?> getAllElectronics() {
		List<Electronic> lele=service.getAllElectronics();
		if(lele!=null)
		{
			return new ResponseEntity<List<Electronic>>(lele,HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	}
}
