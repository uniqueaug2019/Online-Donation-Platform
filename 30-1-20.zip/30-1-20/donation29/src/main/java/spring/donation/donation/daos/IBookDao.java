package spring.donation.donation.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import spring.donation.donation.pojos.Book;
import java.lang.String;
import java.util.List;

@Repository
public interface IBookDao extends JpaRepository<Book, Integer> {
List<Book> findByBookName(String bookname);
}
