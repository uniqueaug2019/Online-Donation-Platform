package spring.donation.donation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.pojos.Category;

@RestController
public class CategoryController {

@Autowired
ICategoryDao dao;
	
@RequestMapping("/getallproducts")
//return all products with category
public ResponseEntity<?> Getall()
{
	List<Category>cl= dao.findAll();
	if(cl!=null) {
	return new ResponseEntity<List<Category>>(cl,HttpStatus.OK);
	}
	return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);	
}
}
