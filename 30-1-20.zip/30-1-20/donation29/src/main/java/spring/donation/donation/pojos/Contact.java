package spring.donation.donation.pojos;

import javax.persistence.Column;
import javax.persistence.Embeddable;

//this class properties embedded into user and only single user table is created with extra column as contactNo 
@Embeddable
public class Contact {
@Column(name="ContactNo",unique = true,length = 15)
private String contactNo;

public Contact() {
	System.out.println("inside contact CTOR");
}
public Contact(String contactNo) {
	super();
	this.contactNo = contactNo;
}
public String getContactNo() {
	return contactNo;
}
public void setContactNo(String contactNo) {
	this.contactNo = contactNo;
}
@Override
public String toString() {
	return "Contact [contactNo=" + contactNo + "]";
}

}


