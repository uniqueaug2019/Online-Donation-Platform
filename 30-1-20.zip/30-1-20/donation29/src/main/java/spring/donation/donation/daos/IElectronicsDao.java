package spring.donation.donation.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import spring.donation.donation.pojos.Electronic;

public interface IElectronicsDao extends JpaRepository<Electronic, Integer>{

}
