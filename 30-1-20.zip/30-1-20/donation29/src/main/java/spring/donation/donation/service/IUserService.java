package spring.donation.donation.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.pojos.User;

public interface IUserService {
public User authenticate(String user);
public boolean register(String name, String email, String password, String dOB, MultipartFile image, String add, String contactNo, String pinCode);
public boolean ChangePassword(String email,String password);
public List<User> getAlluser();
public void deleteUser(int userId);
public User getUserByEmail(String email);
public User updateUserDetails(MultipartFile image,String contact,String userId);
}
