package spring.donation.donation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.IBookDao;
import spring.donation.donation.pojos.Book;
import spring.donation.donation.service.BookServiceImpl;

@RestController()
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BookController {
	@Autowired
	BookServiceImpl service;// auto inject bookservice object

	@Autowired
	IBookDao dao;

	// add new book
	@RequestMapping(value = "/addbook", method = RequestMethod.POST)
	public ResponseEntity<Void> addBook(@RequestParam String bookName, @RequestParam String bookDetails,
			@RequestParam String bookQuantity, @RequestParam String suggestion, @RequestParam String userId,
			@RequestParam(value = "image", required = false) MultipartFile image, @RequestParam String categoryName) {
		System.out.println(bookName + " " + bookDetails + " " + bookQuantity + " " + suggestion + " " + userId + " "
				+ image + " " + categoryName);
		if (service.insertBook(bookName, bookDetails, bookQuantity, suggestion, userId, image, categoryName)) {		
			return new ResponseEntity<Void>( HttpStatus.OK);
		}
		return new ResponseEntity<Void>( HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// delete book
	@RequestMapping(value = "/deletebook/{bookId}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteBook(@PathVariable String bookId){
		System.out.println(bookId);
		try {
			service.deleteBook(Integer.parseInt(bookId));
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	// getallbooks
	@RequestMapping(value = "/getallbooks", method = RequestMethod.GET)
	public ResponseEntity<?>getAllBooks() { 
		List<Book>lb=service.getAllBooks();
		if(lb!=null) {
			return new ResponseEntity<List<Book>>(lb,HttpStatus.OK);
		}
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);		
	}
	
	//serach book by name
	@RequestMapping(value = "/searchbook")
	public ResponseEntity<?>searchBook(@RequestParam String bookName)
	{
		List<Book>lb=service.searchBook(bookName);
		return new ResponseEntity<List<Book>>(lb,HttpStatus.OK);
	}

}
