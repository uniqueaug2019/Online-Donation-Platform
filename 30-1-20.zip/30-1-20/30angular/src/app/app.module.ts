import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'

import { ReactiveFormsModule } from '@angular/forms';




import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { FormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './components/register/register.component';
import { DonateproductsComponent } from './components/donateproducts/donateproducts.component';
import { HomeComponent } from './components/home/home.component';

import { DonateBookComponent } from './components/donateproducts/donate-book/donate-book.component';
import { DonateElectronicComponent } from './components/donateproducts/donate-electronic/donate-electronic.component';
import { TestComponent } from './components/test/test.component';
import { CoroComponent } from './components/coro/coro.component';


import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginhomeComponent } from './components/loginhome/loginhome.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ResetComponent } from './components/reset/reset.component';
//import { TestimageComponent } from './components/testimage/testimage.component';

import { mergeMap, delay } from 'rxjs/operators';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // { path: 'login/donate', component: DonateproductsComponent },
  { path: 'home', component: HomeComponent },
  // { path: 'aboutus', component: AboutusComponent},
  // { path: 'login/donate/books', component:DonateBookComponent},
  // { path: 'login/donate/electronics', component: DonateElectronicComponent },
  { path: 'test', component: TestComponent },
  // { path: 'login/books', component: DonateBookComponent },
  // { path: 'login/electronics', component: DonateElectronicComponent },

  // { path: 'login/profile', component: ProfileComponent },

  { path: 'login/reset', component: ResetComponent },

  //{ path: 'testimage', component: TestimageComponent },

  { path: 'loginhome', component: LoginhomeComponent },


  { path: 'login/loginhome', component: LoginhomeComponent },

  { path: 'loginhome/donate', component: DonateproductsComponent },

  { path: 'loginhome/donate/books', component: DonateBookComponent },
  { path: 'loginhome/profile', component: ProfileComponent },

  { path: 'loginhome/donate/electronics', component: DonateElectronicComponent },



]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,

    DonateproductsComponent,
    HomeComponent,

    DonateBookComponent,
    DonateElectronicComponent,
    TestComponent,
    CoroComponent,
    LoginhomeComponent,
    ProfileComponent,
    ResetComponent,
  //  TestimageComponent,


  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),


    ReactiveFormsModule, NgbModule,




  ],
 
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
