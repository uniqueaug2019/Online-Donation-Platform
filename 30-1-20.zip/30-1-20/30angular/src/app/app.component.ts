import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RestService } from './service/rest.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // nav1: any;
  // nav:boolean=true;
  // ngOnInit() {


  //   this.nav1 = sessionStorage.getItem("nav");
  //   if(this.nav1!=null)
  //   {
  //       this.nav=false;
  //   }
   
  // }  
  title = 'test1';

  change: boolean = false;
  router:string;
  // DI of service
  constructor(private _router: Router,private svc:RestService){
   
  }



  status() {
    this.change = true;
  }




}
