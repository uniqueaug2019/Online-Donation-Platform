import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { DomSanitizer } from '@angular/platform-browser';
import { flatten } from '@angular/compiler';

import { mergeMap, delay, flatMap } from 'rxjs/operators';
import { Router } from '@angular/router';


import { NavigationEnd } from '@angular/router'

@Component({
  selector: 'app-loginhome',
  templateUrl: './loginhome.component.html',
  styleUrls: ['./loginhome.component.css']
})
export class LoginhomeComponent implements OnInit {

  showModal1: boolean;

  showModal2: boolean;
  base64textString: any;
  imagePath: any;
  userObj: any;
  allbooks1: any;
  stringBooks: any;
  img1: any;
  stringElectronics: any;
  showuser: any;
  allelectronics1: any;
  bookUser: any;
  userName: any;
  img2: any;
  electronicUser: any;
  base64textStringO: any
  base64textString2: any
  xyz1: any;

  searchI: string;

  xyz2: any;
  constructor(private svc: RestService, private _sanitizer: DomSanitizer, private router: Router) {
    //window.location.reload();

    //   this.router.routeReuseStrategy.shouldReuseRoute = function () {
    //     return false;
    //   };

    //   this.mySubscription = this.router.events.subscribe((event) => {
    //     if (event instanceof NavigationEnd) {
    //       // Trick the Router into believing it's last link wasn't previously loaded
    //       this.router.navigated = false;
    //     }
    //   });

    // }
    // ngOnDestroy() {
    //   if (this.mySubscription) {
    //     this.mySubscription.unsubscribe();
    //   }
    // }
  }
  ngOnInit() {


    // this.svc.refresh.subscribe(
    //   ()=>{this.getAll()}
    // );
    // this.getAll();









    //  console.log("inside loginHome ALLBOOKS:" + sessionStorage.getItem("ALLBOOKS"));
    //  console.log("inside loginhome init ")
    this.userObj = sessionStorage.getItem("loggedInUser");
    this.userObj = JSON.parse(this.userObj);
    this.userName = this.userObj.name;

    console.log("in init booksstring")
    console.log("inside loginHome ALLBOOKS:" + sessionStorage.getItem("ALLBOOKS"));
    this.allbooks1 = sessionStorage.getItem("ALLBOOKS");


    //console.log("allbooks1"+sessionStorage.getItem("ALLBOOK"));

    this.stringBooks = [] = JSON.parse(this.allbooks1);

    console.log("in init null")
    console.log(this.stringBooks);
    console.log("after")

    this.stringBooks.forEach(element => {
      this.base64textString = element.image;
      this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
        + this.base64textString);
      element.image = this.imagePath;

    });

    this.allelectronics1 = sessionStorage.getItem("ALLELECTRONICS");
    //console.log("allbooks1"+sessionStorage.getItem("ALLBOOK"));
    this.stringElectronics = [] = JSON.parse(this.allelectronics1);

    console.log("in init null")
    console.log(this.stringElectronics);
    console.log("after")

    this.stringElectronics.forEach(element => {
      this.base64textString = element.image;
      this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
        + this.base64textString);
      element.image = this.imagePath;

    });

  }



  show1(image1, bid) {
    console.log("show1")
    this.showModal1 = true; // Show-Hide Modal Check
    this.img1 = image1;
    // this.showuser = user;
    this.getcurrentUserB(bid);
  }
  //Bootstrap Modal Close event
  hide1() {
    this.showModal1 = false;
  }


  show2(image2, eid) {
    console.log("show2")
    this.showModal2 = true; // Show-Hide Modal Check
    this.img2 = image2;
    // this.showuser = user;
    this.getcurrentUserE(eid);
  }
  //Bootstrap Modal Close event
  hide2() {
    this.showModal2 = false;
  }




  statusofPage1() {

    this.router.navigate(["loginhome/profile"]);
  }
  statusofPage2() {
    this.router.navigate(["loginhome/donate"]);
  }
  // getuser() {
  //   console.log(this.alluser1);
  //   console.log(this.alluser1[0].book[0].bookName);
  // }
  logout() {
    console.log("logout clicked");
    sessionStorage.removeItem('loggedInUser');
    sessionStorage.removeItem('loggedInUserId');
    sessionStorage.removeItem('ALLUSERS');

    this.router.navigate(["/"]).then(() => {
      window.location.reload();
    })

    this.svc.isLogOut();
  }

  getcurrentUserB(bookId) {
    console.log("getuser by bookid")
    this.svc.getuserbyBookId(bookId).then(Response => {
      console.log("in get current B user")
      console.log(Response)
      this.bookUser = Response;
      console.log(this.bookUser)

      this.base64textStringO = this.bookUser[0][1];
      this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
        + this.base64textStringO);
      console.log("...................................")
      this.xyz1 = this.imagePath;



    }).catch(error => {
      console.log(error);


    }
    )
  }

  getcurrentUserE(electronicId) {
    console.log("getuser by electronicid")
    this.svc.getuserbyElectronicId(electronicId).then(Response => {
      console.log("in get current E user")
      console.log(Response)
      this.electronicUser = Response;
      console.log(this.electronicUser)


      this.base64textString2 = this.electronicUser[0][1];
      this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
        + this.base64textString2);
      console.log("...................................")
      this.xyz2 = this.imagePath;





    }).catch(error => {
      console.log(error);


    }
    )
  }


  // getAll(){
  //   this.svc.getAllPost().subscribe(
  //     );
  // }

  search(searchI) {

    this.svc.searchI(searchI).then(Response => {


    }).catch(error => {
      console.log(error);


    }
    )

  }

}


