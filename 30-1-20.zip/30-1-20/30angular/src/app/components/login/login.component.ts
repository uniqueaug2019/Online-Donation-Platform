import { Component, OnInit, Output, Input, ɵConsole } from '@angular/core';
import { RestService } from '../../service/rest.service'
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  allusers: any;
  // user22 = [


  // ];
  userObj: any;
  status: boolean = false;
  userLogin: FormGroup;
  msg: string = "";
  loggedInUser: string = null

  submitted = false;



  title = 'test1';


  change: boolean = false;
  oneuser: string;
  allbooks: any;
  constructor(private svc: RestService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.userLogin = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    })


    this.loggedInUser = sessionStorage.getItem('loggedInUser');
    console.log("HELLO" + this.loggedInUser);
  }
  get f() { return this.userLogin.controls; }
  onSubmit() {

    this.submitted = true;

    // stop here if form is invalid
    if (this.userLogin.invalid) {
      return;
    }
    console.log(this.userLogin.value);

    this.login(this.userLogin.value);

  }



  login(user) {

    console.log(user);
    this.svc.login(user).then(response => {
      console.log(response);
      this.status = true;
      this.userObj = response;
      sessionStorage.setItem("nav", "yes");


      sessionStorage.setItem('loggedInUser', JSON.stringify(this.userObj));
      console.log("session get json");
      this.oneuser = sessionStorage.getItem("loggedInUser");
      console.log(JSON.parse(this.oneuser).name);
      console.log(JSON.parse(sessionStorage.getItem("loggedInUser")));
      sessionStorage.setItem('loggedInUserId', this.userObj.userId);
      this.msg = "Login successful";
      this.svc.getallBooks().then(response => {
        //console.log(response);

        this.allbooks = response;
        sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
        console.log("inside login" + sessionStorage.getItem("ALLBOOKS"));

      }).catch(error => {
        console.log(error);
      }
      )

      this.svc.getallElectronics().then(response => {
        //console.log(response);

        this.allbooks = response;
        sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allbooks));
        console.log("inside login" + sessionStorage.getItem("ALLELECTRONICS"));
        console.log("before loginhome");

        console.log("after loginhome");

        this.router.navigate(["loginhome"])

      }).catch(error => {
        console.log(error);


      }
      )



      //  this.getuser();


    }).catch(error => {
      console.log(error);
      this.msg = "Invalid";

    }
    )





  }


  statusofPage() {

    this.router.navigate(["login/reset"]);
  }
}
  // logout() {
  //   console.log("logout clicked");
  //   sessionStorage.removeItem('loggedInUser');
  //   sessionStorage.removeItem('loggedInUserId');
  //   this.router.navigate(["/"]).then(() => {
  //     window.location.reload();
  //   })
  // }





  // statusofPage() {
  //   this.change = true;
  // }



  // getuser() {
  //   this.svc.getuser().then(response => {
  //     console.log(response);
  //     // this.user22.push(response);
  //     // console.log(this.user22);
  //     this.allusers = response;
  //     sessionStorage.setItem('ALLUSERS', JSON.stringify(this.allusers));




  //   }).catch(error => {
  //     console.log(error);


  //   }
  //   )
  // }

// getallBooks(){

// }

// }
