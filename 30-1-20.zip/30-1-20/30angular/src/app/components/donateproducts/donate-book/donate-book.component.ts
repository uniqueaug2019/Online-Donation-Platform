import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { saveAs } from 'file-saver';
import { Router } from '@angular/router';
@Component({
  selector: 'app-donate-book',
  templateUrl: './donate-book.component.html',
  styleUrls: ['./donate-book.component.css']
})
export class DonateBookComponent implements OnInit {
  bookForm: FormGroup;
  book: any;
  selectedFile: File;
  path: any;
  username: any;
  EandP: any;

  status: boolean = false;
  msg: string = "";

  allbooks: any;
  allelectronics: any;
  replaceuser: any;
  constructor(private svc: RestService, private router: Router) { }

  ngOnInit() {

    this.bookForm = new FormGroup({
      bookName: new FormControl(),
      bookDetails: new FormControl(),
      bookQuantity: new FormControl(),
      suggestion: new FormControl(),
      image: new FormControl()
      // categoryName: new FormControl(),
    });


  }





  Submit() {

    this.book = {
      bookName: this.bookForm.get('bookName').value,
      bookDetails: this.bookForm.get('bookDetails').value,
      bookQuantity: this.bookForm.get('bookQuantity').value,
      categoryName: localStorage.getItem("category"),
      userId: sessionStorage.getItem("loggedInUserId"),
      suggestion: this.bookForm.get('suggestion').value,
      image: this.selectedFile
    }
    console.log(this.book);
    this.donate(this.book);

  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0];

    this.path = event.target.files;

    console.log("egfiueguek");
    console.log(this.path);
    console.log(this.selectedFile);


  

  }



  donate(book) {
    // this.username = sessionStorage.getItem("loggedInUser");
    // this.EandP = {
    //   email: this.username.email,
    //   productName: book.bookName
    // }
    // console.log(this.EandP);


    console.log("donate book func")
    console.log(book);

    this.svc.donateBook(book).then(response => {


      console.log("donate book func response")
      console.log(response);


      this.status = true;
      this.msg = "Book Donation successful";


      console.log(this.msg)


      ///overwrite

      this.svc.getallBooks().then(response => {


        this.allbooks = response;
        sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
        console.log("inside profile - login home book" + sessionStorage.getItem("ALLBOOKS"));



      }).catch(error => {
        console.log(error);


      }
      )
      this.svc.getallElectronics().then(response => {


        this.allelectronics = response;
        sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
        console.log("inside profile - login home electronic" + sessionStorage.getItem("ALLELECTRONICS"));



      }).catch(error => {
        console.log(error);


      }
      )
















    }).catch(error => {

      console.log("donate book func error")
      console.log(error);
      // this.msg = "Invalid";

      this.msg = "Book Donation unsuccessful";
      // console.log(this.msg)
    }
    )





    // register(user) {
    //   this.svc.register(user).then(response => {
    //     console.log(response);
    //     this.status = true;
    //     this.msg = "Register successful";

    //   }).catch(error => {
    //     console.log(error);
    //     this.msg = "Register unsuccessful";

    //   }
    //   )

    // this.svc.getmailfordonation(this.EandP).then(response => {
    //   console.log(response);
    // this.status = true;
    // this.msg = "Book Donation successful";



    // }).catch(error => {
    //   console.log(error);
    // this.msg = "Invalid";
    // this.msg = "Book Donation unsuccessful";

    // }
    // )


  }
  goback() {
    this.svc.getallBooks().then(response => {
      //console.log(response);

      this.allbooks = response;
      sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
      console.log("inside profile - login home" + sessionStorage.getItem("ALLBOOKS"));



    }).catch(error => {
      console.log(error);


    }
    )


    this.svc.getallElectronics().then(response => {
      //console.log(response);

      this.allelectronics = response;
      sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
      console.log("inside profile - login home" + sessionStorage.getItem("ALLELECTRONICS"));



    }).catch(error => {
      console.log(error);


    }
    )



    this.svc.getuserbyEmail(JSON.parse(sessionStorage.getItem("loggedInUser")).email).then(response => {

      this.replaceuser = response;

      sessionStorage.setItem("loggedInUser", JSON.stringify(this.replaceuser));

      ////////




    }).catch(error => {
      console.log(error);
    }
    )






    this.router.navigate(["loginhome"])





  }

}
