import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestService } from 'src/app/service/rest.service';
@Component({
  selector: 'app-donateproducts',
  templateUrl: './donateproducts.component.html',
  styleUrls: ['./donateproducts.component.css']
})
export class DonateproductsComponent implements OnInit {
  allbooks: any;
  allelectronics: any;

  replaceuser:any;
  constructor(private router: Router, private svc: RestService) { }

  ngOnInit() {
  }


  setCategoryBooks() {

    //console.log(event);
    localStorage.setItem("category", "books");
  }
  setCategoryElectronics() {

    //console.log(event);
    localStorage.setItem("category", "electronics");

  }

  goback() {
    this.svc.getallBooks().then(response => {
      //console.log(response);

      this.allbooks = response;
      sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
      console.log("inside profile - login home" + sessionStorage.getItem("ALLBOOKS"));



    }).catch(error => {
      console.log(error);


    }
    )


    this.svc.getallElectronics().then(response => {
      //console.log(response);

      this.allelectronics = response;
      sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
      console.log("inside profile - login home" + sessionStorage.getItem("ALLELECTRONICS"));



    }).catch(error => {
      console.log(error);


    }
    )



    this.svc.getuserbyEmail(JSON.parse(sessionStorage.getItem("loggedInUser")).email).then(response => {

      this.replaceuser = response;

      sessionStorage.setItem("loggedInUser", JSON.stringify(this.replaceuser));

      ////////




    }).catch(error => {
      console.log(error);
    }
    )













    this.router.navigate(["loginhome"])
  }
}
