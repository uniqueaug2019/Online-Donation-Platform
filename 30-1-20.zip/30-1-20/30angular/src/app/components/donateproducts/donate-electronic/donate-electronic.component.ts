import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { saveAs } from 'file-saver';
import { Router } from '@angular/router';

@Component({
  selector: 'app-donate-electronic',
  templateUrl: './donate-electronic.component.html',
  styleUrls: ['./donate-electronic.component.css']
})
export class DonateElectronicComponent implements OnInit {

  electronicForm: FormGroup;
  electronic: any;
  selectedFile: File;
  path: any;
  username: any;
  EandP: any;

  status: boolean = false;
  msg: string = "";


  allbooks: any;
  allelectronics: any;
  replaceuser: any;
  constructor(private svc: RestService, private router: Router) { }

  ngOnInit() {

    this.electronicForm = new FormGroup({
      electronicName: new FormControl(),
      electronicDetails: new FormControl(),
      electronicQuantity: new FormControl(),
      suggestion: new FormControl(),
      image: new FormControl()
      // categoryName: new FormControl(),
    });


  }





  Submit() {

    this.electronic = {
      electronicName: this.electronicForm.get('electronicName').value,
      electronicDetails: this.electronicForm.get('electronicDetails').value,
      electronicQuantity: this.electronicForm.get('electronicQuantity').value,
      categoryName: localStorage.getItem("category"),
      userId: sessionStorage.getItem("loggedInUserId"),
      suggestion: this.electronicForm.get('suggestion').value,
      image: this.selectedFile
    }
    console.log(this.electronic);
    this.donate(this.electronic);

  }







  onFileChanged(event) {
    this.selectedFile = event.target.files[0];

    this.path = event.target.files;

    console.log("egfiueguek");
    console.log(this.path);
    console.log(this.selectedFile);


  }



  donate(electronic) {
    // this.username = sessionStorage.getItem("loggedInUser");
    // this.EandP = {
    //   email: this.username.email,
    //   productName: electronic.electronicName
    // }
    // console.log(this.EandP);



    console.log(electronic);
    this.svc.donateElectronic(electronic).then(

      response => {

        console.log("in response");
        console.log(response);
        this.status = true;
        this.msg = "Electronic Donation successful";




        ///overwrite

        this.svc.getallBooks().then(response => {


          this.allbooks = response;
          sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
          console.log("inside profile - login home book" + sessionStorage.getItem("ALLBOOKS"));



        }).catch(error => {
          console.log(error);


        }
        )
        this.svc.getallElectronics().then(response => {


          this.allelectronics = response;
          sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
          console.log("inside profile - login home electronic" + sessionStorage.getItem("ALLELECTRONICS"));



        }).catch(error => {
          console.log(error);


        }
        )






      }).catch(error => {
        console.log(error);
        console.log("in error");
        this.status = false;
        this.msg = "Electronic Donation unsuccessful";

      }
      )
  }
  goback() {


    this.svc.getallBooks().then(response => {
      //console.log(response);

      this.allbooks = response;
      sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
      console.log("inside profile - login home" + sessionStorage.getItem("ALLBOOKS"));



    }).catch(error => {
      console.log(error);


    }
    )


    this.svc.getallElectronics().then(response => {
      //console.log(response);

      this.allelectronics = response;
      sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
      console.log("inside profile - login home" + sessionStorage.getItem("ALLELECTRONICS"));



    }).catch(error => {
      console.log(error);


    }
    )



    this.svc.getuserbyEmail(JSON.parse(sessionStorage.getItem("loggedInUser")).email).then(response => {

      this.replaceuser = response;

      sessionStorage.setItem("loggedInUser", JSON.stringify(this.replaceuser));

      ////////




    }).catch(error => {
      console.log(error);
    }
    )
    this.router.navigate(["loginhome"])
  }

}
