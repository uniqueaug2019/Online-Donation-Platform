import { Component, OnInit } from '@angular/core';



import { DomSanitizer } from '@angular/platform-browser';
import { RouterModule, Router } from '@angular/router';
import { RestService } from 'src/app/service/rest.service';



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  selectedFile: File;
  loggedinUser: any;
  base64textString: any;
  imagePath: any;
  alluser1: any;
  stringUser: any;
  book: any;
  loginUser: any;
  other: any;
  stringUserD: any;
  newUser: any;

  replaceuser: any;


  allbooks: any;
  allelectronics: any;


  constructor(private _sanitizer: DomSanitizer, private router: Router, private svc: RestService) { }




  ngOnInit() {

    // this.oneuser=sessionStorage.getItem("loggedInUser");
    // console.log(JSON.parse(this.oneuser).name);
    this.loggedinUser = sessionStorage.getItem("loggedInUser");
    this.stringUser = JSON.parse(this.loggedinUser)

    console.log("in init profile");
    console.log(this.stringUser.name);
    console.log(this.loggedinUser);


    this.base64textString = this.stringUser.image;
    this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
      + this.base64textString);
    console.log(this.imagePath)
    this.stringUser.image = this.imagePath;


    this.alluser1 =
    {
      userId: this.stringUser.userId,
      name: this.stringUser.name,
      email: this.stringUser.email,
      password: "N/A",
      image: this.stringUser.image,
      contact: {
        contactNo: this.stringUser.contact.contactNo,
      },
      address: {
        addressId: this.stringUser.address.addressId,
        address: this.stringUser.address.address,
        pinCode: this.stringUser.address.pinCode,
      },
      book: this.stringUser.books,

      electronic: this.stringUser.electronics,
      dob: this.stringUser.dob,
    }


    console.log("alluser1...................");

    // console.log(this.alluser1);
    // this.base64textString = this.stringUser.image;
    // this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
    //   + this.base64textString);
    // console.log(this.imagePath)
    // this.stringUser.image = this.imagePath;

  }

  goback() {


    // this.svc.getallBooks().then(response => {


    //   this.allbooks = response;
    //   sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
    //   console.log("inside profile - login home book" + sessionStorage.getItem("ALLBOOKS"));



    // }).catch(error => {
    //   console.log(error);


    // }
    // )
    // this.svc.getallElectronics().then(response => {


    //   this.allelectronics = response;
    //   sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
    //   console.log("inside profile - login home electronic" + sessionStorage.getItem("ALLELECTRONICS"));



    // }).catch(error => {
    //   console.log(error);


    // }
    // )


    //   this.router.navigateByUrl('/loginhome', { skipLocationChange: true }).then(() => {
    //     this.router.navigate(['LoginHomeComponent']);
    // });


    this.router.navigate(["/login/loginhome"]);

  }

  // getimthis.loginUsera.then(response =>
  // gesanitizer() {
  //   this.base64textString=this.loggedinUser.image;
  //   this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
  //     + this.base64textString);
  // }


  updateProfile(contact) {

    this.loggedinUser = sessionStorage.getItem("loggedInUser");
    this.stringUser = JSON.parse(this.loggedinUser)



    this.svc.updateuser(this.selectedFile, contact, this.stringUser.userId).then(response => {
      console.log(response);


      //
      this.replaceuser = response;

      sessionStorage.setItem("loggedInUser", JSON.stringify(this.replaceuser));

      ////////

      this.loggedinUser = sessionStorage.getItem("loggedInUser");
      this.stringUser = JSON.parse(this.loggedinUser)

      console.log("in rest update function ");
      console.log(this.stringUser.name);
      console.log(this.loggedinUser);




      this.base64textString = this.stringUser.image;
      this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
        + this.base64textString);
      console.log(this.imagePath)
      this.stringUser.image = this.imagePath;



      this.alluser1 =
      {
        userId: this.stringUser.userId,
        name: this.stringUser.name,
        email: this.stringUser.email,
        password: "N/A",
        image: this.stringUser.image,
        contact: {
          contactNo: this.stringUser.contact.contactNo,
        },
        address: {
          addressId: this.stringUser.address.addressId,
          address: this.stringUser.address.address,
          pinCode: this.stringUser.address.pinCode,
        },
        book: this.stringUser.books,

        electronic: this.stringUser.electronics,
        dob: this.stringUser.dob,
      }


    }).catch(error => {
      console.log(error);
      console.log("error in user deleted")

    }
    )




  }

  deleteP(password) {


    this.newUser = {
      email: this.stringUser.email,
      password: password
    }

    this.svc.login(this.newUser).then(response => {
      console.log(response);


      this.svc.deleteuser(this.stringUser.userId).then(response => {
        console.log(response);

        console.log("user deleted")

        // sessionStorage.removeItem("loggedInUser");
        this.router.navigate(['home']);
        location.reload();

        //logg outs

        console.log("logout clicked");
        sessionStorage.removeItem('loggedInUser');
        sessionStorage.removeItem('loggedInUserId');
        sessionStorage.removeItem('ALLUSERS');

        this.router.navigate(["/"]).then(() => {
          window.location.reload();
        })

        this.svc.isLogOut();

      }).catch(error => {
        console.log(error);
        console.log("error in user deleted")

      }
      )


    }).catch(error => {
      console.log(error);

      console.log("not valid user")

    }
    )

  }


  deletebook(bookId) {



    this.svc.deletebook(bookId).then(response => {
      console.log(response);



      this.svc.getuserbyEmail(JSON.parse(sessionStorage.getItem("loggedInUser")).email).then(response => {

        this.replaceuser = response;

        sessionStorage.setItem("loggedInUser", JSON.stringify(this.replaceuser));

        ////////

        this.loggedinUser = sessionStorage.getItem("loggedInUser");
        this.stringUser = JSON.parse(this.loggedinUser)

        console.log("in rest function ");
        console.log(this.stringUser.name);
        console.log(this.loggedinUser);
        this.base64textString = this.stringUser.image;
        this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
          + this.base64textString);
        console.log(this.imagePath)
        this.stringUser.image = this.imagePath;



        this.alluser1 =
        {
          userId: this.stringUser.userId,
          name: this.stringUser.name,
          email: this.stringUser.email,
          password: "N/A",
          image: this.stringUser.image,
          contact: {
            contactNo: this.stringUser.contact.contactNo,
          },
          address: {
            addressId: this.stringUser.address.addressId,
            address: this.stringUser.address.address,
            pinCode: this.stringUser.address.pinCode,
          },
          book: this.stringUser.books,

          electronic: this.stringUser.electronics,
          dob: this.stringUser.dob,
        }

        // location.reload();


        this.svc.getallBooks().then(response => {


          this.allbooks = response;
          sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
          console.log("inside profile - login home book" + sessionStorage.getItem("ALLBOOKS"));



        }).catch(error => {
          console.log(error);


        }
        )
        this.svc.getallElectronics().then(response => {


          this.allelectronics = response;
          sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
          console.log("inside profile - login home electronic" + sessionStorage.getItem("ALLELECTRONICS"));



        }).catch(error => {
          console.log(error);


        }
        )


      }).catch(error => {
        console.log(error);
      }
      )


      // this.loginUser = sessionStorage.getItem("loggedInUser");
      // this.stringUserD = JSON.parse(this.loginUser)
      // this.other = this.stringUserD.userId
      // this.svc.login(this.other).then(response => {
      //   console.log("login inside delete response" + response);
      //   this.loginUser = response;
      //   sessionStorage.setItem("loggedInUser", this.loginUser)



      // }).catch(error => {
      //   console.log(error);
      // }
      // )





    }).catch(error => {
      console.log(error);
    }
    )

  }
  deleteelectronic(electronicId) {
    this.svc.deleteelectronic(electronicId).then(response => {
      console.log(response);

      this.svc.getuserbyEmail(JSON.parse(sessionStorage.getItem("loggedInUser")).email).then(response => {

        this.replaceuser = response;

        sessionStorage.setItem("loggedInUser", JSON.stringify(this.replaceuser));

        ////////

        this.loggedinUser = sessionStorage.getItem("loggedInUser");
        this.stringUser = JSON.parse(this.loggedinUser)

        console.log("in rest function ");
        console.log(this.stringUser.name);
        console.log(this.loggedinUser);
        this.base64textString = this.stringUser.image;
        this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
          + this.base64textString);
        console.log(this.imagePath)
        this.stringUser.image = this.imagePath;



        this.alluser1 =
        {
          userId: this.stringUser.userId,
          name: this.stringUser.name,
          email: this.stringUser.email,
          password: "N/A",
          image: this.stringUser.image,
          contact: {
            contactNo: this.stringUser.contact.contactNo,
          },
          address: {
            addressId: this.stringUser.address.addressId,
            address: this.stringUser.address.address,
            pinCode: this.stringUser.address.pinCode,
          },
          book: this.stringUser.books,

          electronic: this.stringUser.electronics,
          dob: this.stringUser.dob,
        }

        // location.reload();



        this.svc.getallBooks().then(response => {


          this.allbooks = response;
          sessionStorage.setItem("ALLBOOKS", JSON.stringify(this.allbooks));
          console.log("inside profile - login home book" + sessionStorage.getItem("ALLBOOKS"));



        }).catch(error => {
          console.log(error);


        }
        )
        this.svc.getallElectronics().then(response => {


          this.allelectronics = response;
          sessionStorage.setItem("ALLELECTRONICS", JSON.stringify(this.allelectronics));
          console.log("inside profile - login home electronic" + sessionStorage.getItem("ALLELECTRONICS"));



        }).catch(error => {
          console.log(error);


        }
        )



      }).catch(error => {
        console.log(error);
      }
      )

    }).catch(error => {
      console.log(error);
    }
    )


  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0]
    console.log(this.selectedFile);

  }

}
