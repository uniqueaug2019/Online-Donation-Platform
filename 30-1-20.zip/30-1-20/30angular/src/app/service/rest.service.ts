import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RestService {
  // url
  url: string = "http://192.168.76.217:8090/";


  refresh = new Subject();

  constructor(private http: HttpClient) { }

////////////////
  // writePost(p): Observable<any> {

  //   return this.http.get(this.url + "getallbooks").pipe(
  //     tap(
  //       () => { this.refresh.next(); }
  //     )
  //   )
  // }


  // getAllPost():Observable<any>{
  //   return this.http.get(this.url + "getallbooks");
  // }



///////////////////////





  //user login
  login(user) {
    return this.http.post(this.url + "login", user).toPromise();
  }
  //register login
  register(user) {

    const formdata = new FormData();
    formdata.append("name", user.name);
    formdata.append("email", user.email);
    formdata.append("password", user.password);
    formdata.append("DOB", user.dOB);
    formdata.append("contactNo", user.contactNo);
    formdata.append("pinCode", user.pinCode);
    formdata.append("add", user.add);
    formdata.append("image", user.image);
    console.log("iueyfgeyubi");
    console.log(formdata);
    return this.http.post(this.url + "register", formdata).toPromise();
  }
  donateBook(book) {

    const formdata = new FormData();
    formdata.append("bookName", book.bookName);
    formdata.append("bookDetails", book.bookDetails);
    formdata.append("bookQuantity", book.bookQuantity);
    formdata.append("suggestion", book.suggestion);
    formdata.append("userId", book.userId);
    formdata.append("categoryName", book.categoryName);
    formdata.append("image", book.image);
    return this.http.post(this.url + "addbook", formdata).toPromise();
  }

  donateElectronic(electronic) {

    const formdata = new FormData();
    formdata.append("electronicName", electronic.electronicName);
    formdata.append("electronicDetails", electronic.electronicDetails);
    formdata.append("electronicQuantity", electronic.electronicQuantity);
    formdata.append("suggestion", electronic.suggestion);
    formdata.append("userId", electronic.userId);
    formdata.append("categoryName", electronic.categoryName);
    formdata.append("image", electronic.image);
    return this.http.post(this.url + "addelectronic", formdata).toPromise();
  }
  //reset password
  reset(user) {
    return this.http.post(this.url + "email/sendEmail", user).toPromise();
  }


  image(istring) {
    return this.http.post(this.url + "", istring).toPromise();
  }

  //get all users
  getuser() {
    return this.http.get(this.url + "getalluser").toPromise();
  }

  deleteelectronic(electronicId) {
    return this.http.delete(this.url + "deleteelectronic/" + electronicId).toPromise();
  }
  deleteuser(userId) {
    return this.http.delete(this.url + "deleteuser/" + userId).toPromise();
  }

  deletebook(bookId) {
    return this.http.delete(this.url + "deletebook/" + bookId).toPromise();
  }
  // getmailfordonation(EandP) {
  //   return this.http.post(this.url + "email/sendProductUpdateMail", EandP).toPromise();
  // }
  //check if login user stored in session 
  isLogin() {
    let user = sessionStorage.getItem('nav');
    //  console.log(user);
    let r = user === null;
    //  console.log(r);
    return r
  }

  isLogOut() {
    sessionStorage.removeItem('nav');
  }

  getallBooks() {
    return this.http.get(this.url + "getallbooks").toPromise();
  }

  getallElectronics() {
    return this.http.get(this.url + "getallelectronics").toPromise();
  }


  getuserbyBookId(bookId) {
    console.log("RESTTTTT book")
    return this.http.get(this.url + "getbookuser/" + bookId).toPromise();
  }

  getuserbyElectronicId(electronicId) {
    console.log("RESTTTTT eleect")
    return this.http.get(this.url + "getelectronicuser/" + electronicId).toPromise();
  }

  getuserbyEmail(email) {
    const email1 = new FormData();
    email1.append("email", email);
    console.log("EMAIL>>>>>>>>>>>>>>>>>>>>")
    return this.http.post(this.url + "getuserbyemail", email1).toPromise();
  }

  updateuser(image, contact, userId) {

    const formdata = new FormData();
    formdata.append("image", image);
    formdata.append("contact", contact);
    formdata.append("userId", userId);
    return this.http.post(this.url + "updateuserdetails", formdata).toPromise();
  }


  searchI(s){
    return this.http.get(this.url + "getallelectronics").toPromise();
  }
  
}
