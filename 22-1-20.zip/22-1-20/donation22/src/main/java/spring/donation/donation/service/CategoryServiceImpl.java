package spring.donation.donation.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Books;
import spring.donation.donation.pojos.Category;
import spring.donation.donation.pojos.User;

@Service
public class CategoryServiceImpl implements ICategoryService {

	@Autowired
	ICategoryDao catdao;

	@Autowired
	IUserDao userdao;

	@Override
	public boolean InsertBook(String book) throws JsonMappingException, JsonProcessingException {
		Category tempcat=null;
		boolean status = false;

		System.out.println("inside insert book");// just for checking flow
		System.out.println(book);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonNode = mapper.readTree(book);

		// extracting data from jsonobject 
		String bookName =jsonNode.get("bookName").asText();
		String bookDetails = jsonNode.get("bookDetails").asText();
		int bookQuantity = jsonNode.get("bookQuantity").asInt();
		String categoryName = jsonNode.get("categoryName").asText();
		int userId = jsonNode.get("userId").asInt();
		
		User user=userdao.getOne(userId);		
		// first fetch category by categoryname
		List<Category> tb = catdao.findByCategoryName(categoryName);
		try {
			tempcat = tb.get(0);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Books bk=new Books(bookName, bookDetails, bookQuantity);
		bk.setBookuser(user);
		// add new book into books category
		tempcat.addBook(bk);
		if (catdao.save(tempcat)!= null)// if record found it returns record
		{
			status = true;
		}
		return status;
	}
}
