import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donate-electronic',
  templateUrl: './donate-electronic.component.html',
  styleUrls: ['./donate-electronic.component.css']
})
export class DonateElectronicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
