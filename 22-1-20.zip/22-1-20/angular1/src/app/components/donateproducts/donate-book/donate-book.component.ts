import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-donate-book',
  templateUrl: './donate-book.component.html',
  styleUrls: ['./donate-book.component.css']
})
export class DonateBookComponent implements OnInit {
  bookForm: FormGroup;
  book: any;
  constructor(private svc: RestService) { }

  ngOnInit() {

    this.bookForm = new FormGroup({
      bookName: new FormControl(),
      bookDetails: new FormControl(),
      bookQuantity: new FormControl(),
      // categoryName: new FormControl(),
    });

    
  }


  Submit() {
  
    this.book = {
      bookName: this.bookForm.get('bookName').value,
      bookDetails: this.bookForm.get('bookDetails').value,
      bookQuantity: this.bookForm.get('bookQuantity').value,
      categoryName:localStorage.getItem("category"),
      userId:sessionStorage.getItem("loggedInUser")
    }
    console.log(this.book);
    this.donate(this.book);
  }


  donate(book) {

    console.log(book);

    console.log(book);
    this.svc.donate(book).then(response => {
      console.log(response);


      // this.msg = "Login successful";

    }).catch(error => {
      console.log(error);
      // this.msg = "Invalid";

    }
    )
  }

}
