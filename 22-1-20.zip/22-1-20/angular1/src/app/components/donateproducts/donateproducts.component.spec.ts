import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonateproductsComponent } from './donateproducts.component';

describe('DonateproductsComponent', () => {
  let component: DonateproductsComponent;
  let fixture: ComponentFixture<DonateproductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonateproductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonateproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
