import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  showModal: boolean;
  constructor() { }

  images=[
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",
"../assets/images/mrmercides.jfif",

    
  ]


  ngOnInit() {
  }
  show()
  {
    this.showModal = true; // Show-Hide Modal Check
    
  }
  //Bootstrap Modal Close event
  hide()
  {
    this.showModal = false;
  }



}
