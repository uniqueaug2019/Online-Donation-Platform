package spring.donation.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import spring.donation.donation.service.BookServiceImpl;

@RestController()
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BookController {
	@Autowired
	BookServiceImpl service;// auto inject bookservice object

	//add new book
	@RequestMapping(value = "/addbook", method = RequestMethod.POST)
	public String addBook(@RequestBody String book) throws Exception {
		System.out.println("DONEEEEEEEE");
		String msg = "INSERTION FAILED";
		System.out.println(book);
		if (service.insertBook(book)) {
			msg = "BOOK INSERTED SUCCESSFULLY";
		}
		return msg;
	}

	// delete book
	@RequestMapping(value = "/deleteBook/{bookId}", method = RequestMethod.DELETE)
	public String deleteBook(@PathVariable String bookId) throws Exception {
		String msg = "BOOK DELETED SUCCESSFULLY";
		System.out.println(bookId);
		service.deleteBook(Integer.parseInt(bookId));					
		return msg;
	}
}
