package spring.donation.donation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import spring.donation.donation.pojos.Books;
import spring.donation.donation.pojos.User;

public interface IBookService {

	public boolean insertBook(String book) throws JsonMappingException, JsonProcessingException;
	
	public boolean deleteBook(int bookId) ;
	
}
