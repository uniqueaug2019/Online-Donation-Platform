package spring.donation.donation.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.donation.donation.daos.IimageDao;

@RestController
@CrossOrigin(value = "*" ,allowedHeaders = "*")
public class ImageController {
	
	@Autowired
	IimageDao dao;	
	public static String Location = System.getProperty("user.dir") + "/imageuploads";
	
    @RequestMapping(value = "/upload" ,method = RequestMethod.POST)
	public String processUploadForm(@RequestParam MultipartFile contents, Model map)  {
		String msg=contents.getOriginalFilename()+ "uploaded successfully";		
		System.out.println("in process upload " + Location+"/"+contents.getOriginalFilename());			
		Path path = Paths.get(Location, contents.getOriginalFilename());
		try {
		Files.write(path, msg.getBytes());
		}catch(IOException e)
		{
			msg="Error In uploading file";
		}						
		return msg ;
	}
    
    @GetMapping("download/{fileName}")
	@ResponseBody
	public String downloadFile(@PathVariable String fileName, HttpServletResponse resp, HttpServletRequest request) {
		try {
			File f1 = new File(Location, fileName);
			byte[] data = FileUtils.readFileToByteArray(f1);
			return new String(Base64.encodeBase64(data), "UTF-8");
		} catch (Exception e) {
			System.out.println("err in download " + e);
		}
		return "Error in downloading image data";

	}
}


