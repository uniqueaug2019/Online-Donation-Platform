package spring.donation.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring.donation.donation.daos.ICategoryDao;
import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Books;
import spring.donation.donation.pojos.Category;
import spring.donation.donation.pojos.Electronics;
import spring.donation.donation.pojos.User;

@Service
public class ElectronicServiceImpl implements IElectronicService {
	@Autowired
	ICategoryDao catdao;
	
    @Autowired
    IUserDao userdao;
    
	@Override
	public boolean insertElectronic(String electronic) {
		
		Category tempcat=null;
		boolean status = false;

		System.out.println("inside insert book");// just for checking flow
		System.out.println(electronic);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonNode = null;
		try {
			jsonNode = mapper.readTree(electronic);
		} catch (JsonMappingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// extracting data from jsonobject 
		String electronicName =jsonNode.get("electronicName").asText();
		String electronicDetail = jsonNode.get("electronicDetail").asText();
		int electronicQuantity = jsonNode.get("electronicQuantity").asInt();
		String categoryName = jsonNode.get("categoryName").asText();
		int userId = jsonNode.get("userId").asInt();
		String suggestion=jsonNode.get("suggestion").asText();
		
		User user=userdao.getOne(userId);		
		// first fetch category by categoryname
		List<Category> tb = catdao.findByCategoryName(categoryName);
		try {
			tempcat = tb.get(0);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Electronics el=new Electronics(electronicName,electronicDetail,electronicQuantity,suggestion);
		el.setElectronicUser(user);
		// add new book into books category
		tempcat.addElectronic(el);
		if (catdao.save(tempcat)!= null)// if record found it returns record
		{
			status = true;
		}
		return status;
	}

	@Override
	public void deleteElectronic(int electronicId) {
		//write after sometime
		
	}

}
