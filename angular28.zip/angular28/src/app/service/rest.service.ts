import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class RestService {

  url: string = "http://192.168.76.217:8090/"
  // url:string="http://192.168.43.110:8080/"
  // url:string="http://192./"
  constructor(private http: HttpClient) { }

  login(user) {
    return this.http.post(this.url + "login", user).toPromise();
  }

  register(user) {

    const formdata = new FormData();
    formdata.append("name", user.name);
    formdata.append("email", user.email);
    formdata.append("password", user.password);
    formdata.append("DOB", user.dOB);
    formdata.append("contactNo", user.contactNo);
    formdata.append("pinCode", user.pinCode);
    formdata.append("add", user.add);
    formdata.append("image", user.image);
    console.log("iueyfgeyubi");
    console.log(formdata);
    return this.http.post(this.url + "register", formdata).toPromise();
  }
  donate(book) {

    const formdata = new FormData();
    formdata.append("bookName", book.bookName);
    formdata.append("bookDetails", book.bookDetails);
    formdata.append("bookQuantity", book.bookQuantity);
    formdata.append("suggestion", book.suggestion);
    formdata.append("userId", book.userId);
    formdata.append("categoryName", book.categoryName);
    formdata.append("image", book.image);
    return this.http.post(this.url + "addbook", formdata).toPromise();
  }

  reset(user) {
    return this.http.post(this.url + "email/sendEmail", user).toPromise();
  }


  image(istring) {
    return this.http.post(this.url + "", istring).toPromise();
  }


  getuser() {
    return this.http.get(this.url + "getalluser").toPromise();
  }


  deletebook(bookId){
    return this.http.delete(this.url+"deletebook/"+bookId).toPromise();
  }
  // getmailfordonation(EandP) {
  //   return this.http.post(this.url + "email/sendProductUpdateMail", EandP).toPromise();
  // }

  isLogin()
  {
    let user=sessionStorage.getItem('nav');
    console.log(user);
    let r= user===null;
    console.log(r);
    return r
  }

  isLogOut(){
    sessionStorage.removeItem('nav');
  }


}
