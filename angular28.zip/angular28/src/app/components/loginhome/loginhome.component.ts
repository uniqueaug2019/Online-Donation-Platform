import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { DomSanitizer } from '@angular/platform-browser';
import { flatten } from '@angular/compiler';

import { mergeMap, delay, flatMap } from 'rxjs/operators';
import { Router } from '@angular/router';
@Component({
  selector: 'app-loginhome',
  templateUrl: './loginhome.component.html',
  styleUrls: ['./loginhome.component.css']
})
export class LoginhomeComponent implements OnInit {

  showModal: boolean;
  alluser1: any;
  stringUser: any;
  alluser2 = [];
  arrayofuser: any;
  base64textString: any;
  imagePath: any;

  constructor(private svc: RestService, private _sanitizer: DomSanitizer,private router:Router) { }










  // booksimages = [
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",


  // ];

  // electronicsimages = [
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",
  //   "../assets/images/mrmercides.jfif",
  //   "../assets/images/sherlockholmes.jfif",
  //   "../assets/images/moana.jfif",
  //   "../assets/images/studysmart.jfif",
  //   "../assets/images/gobletoffire.jfif",
  //   "../assets/images/encounters.jfif",
  //   "../assets/images/dune.jfif",
  //   "../assets/images/completecollection.jfif",


  // ];
  img1: any;

  // alluser1: any = sessionStorage.getItem("ALLUSERS");
  // stringUser = JSON.parse(this.alluser1)

  // alluser2 =
  // {
  //   userId: this.stringUser.userId,
  //   name: this.stringUser.name,
  //   email: this.stringUser.email,
  //   password: "N/A",
  //   image: this.stringUser.image,
  //   contact: {
  //     contactNo: this.stringUser.contact.contactNo,
  //   },
  //   address: {
  //     addressId: this.stringUser.address.addressId,
  //     address: this.stringUser.address.address,
  //     pinCode: this.stringUser.address.pinCode,
  //   },
  //   book: this.stringUser.book,

  //   electronic: this.stringUser.book,
  //   dob: this.stringUser.dob,
  // }

  showuser: any;
userObj=sessionStorage.getItem("loggedInUser");
  // alluser1 = [
  //   {
  //     userId: 2,
  //     name: "prasad",
  //     email: "onkar@123",
  //     password: "N/A",
  //     image: null,
  //     contact: {
  //       contactNo: 222222,
  //     },
  //     address: {
  //       addressId: 1,
  //       address: "pune",
  //       pinCode: 123456789,
  //     },
  //     book: [
  //       { bookId: 4, bookName: "name1", bookDetails: "very good book", bookQuantity: 2, suggestion: null },
  //       { bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null }
  //     ],
  //     electronic:[
  //       {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
  //     ],
  //     dob: "2020-01-10",
  //   },
  //   {
  //     userId: 2,
  //     name: "subodh",
  //     email: "subodh@123",
  //     password: "N/A",
  //     image: null,
  //     contact: {
  //       contactNo: 1111111,
  //     },
  //     address: {
  //       addressId: 1,
  //       address: "pune",
  //       pinCode: 123456789,
  //     },
  //     book: [
  //       { bookId: 4, bookName: "name2", bookDetails: "very good book", bookQuantity: 2, suggestion: null },
  //       { bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null }
  //     ],
  //     electronic:[
  //       {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
  //     ],
  //     dob: "2020-01-10",
  //   },
  //   {
  //     userId: 2,
  //     name: "prasad",
  //     email: "onkar@123",
  //     password: "N/A",
  //     image: null,
  //     contact: {
  //       contactNo: 222222,
  //     },
  //     address: {
  //       addressId: 1,
  //       address: "pune",
  //       pinCode: 123456789,
  //     },
  //     book: [
  //       { bookId: 4, bookName: "nmae3", bookDetails: "very good book", bookQuantity: 2, suggestion: null },
  //       { bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null }
  //     ],
  //     electronic:[
  //       {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
  //     ],
  //     dob: "2020-01-10",
  //   }
  // ]
  ngOnInit() {

    this.alluser1 = sessionStorage.getItem("ALLUSERS");
    this.stringUser = [] = JSON.parse(this.alluser1);

    console.log("string user in login home")
    console.log(this.stringUser);

    this.stringUser.forEach(element => {
      //   this.base64textString = element.book.image;
      // this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
      //   + this.base64textString);
      // element.book.image=this.imagePath;
      // console.log("image.......");
      // console.log(this.imagePath);
      element.book.forEach(element => {
        this.base64textString = element.image;
        this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
          + this.base64textString);
        element.image = this.imagePath;
        console.log("image.......");
        console.log(this.imagePath);

      });

    });
    this.stringUser.forEach(element => {
      this.alluser2.push(element);
      
    });

    // this.stringUser.forEach(element => {
     
    //   this.alluser2.push(element.name);
    //   this.alluser2.push(element.email);
    //   this.alluser2.push(element.contact.contactNo);
    //   this.alluser2.push(element.address.address);
    //   this.alluser2.push(element.address.pinCode);
    //   element.book.forEach(element => {
    //     this.alluser2.push(element.bookName);
    //     this.alluser2.push(element.bookDetails);
    //     this.alluser2.push(element.bookQuantity);
    //     this.alluser2.push(element.suggestion);
    //     this.alluser2.push(element.image);
    //   });
    //   this.alluser2.push(element.dob);



    // });


  //   console.log("flattttttttt");

  //  this.alluser2= [].concat.apply([], this.alluser2);
  //  console.log("flattttttttt");
  //  console.log(this.alluser2);





    console.log("image.......");
    // console.log(this.stringUser[0].book.image);







    // console.log(this.alluser2);
    // this.base64textString = this.stringUser.image;
    // this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
    //   + this.base64textString);
    // console.log(this.imagePath)

    console.log("in inonit login home")
    console.log(this.alluser2);



  }



  show(image, user) {
    this.showModal = true; // Show-Hide Modal Check
    this.img1 = image;
    this.showuser = user;
  }
  //Bootstrap Modal Close event
  hide() {
    this.showModal = false;
  }




  statusofPage1() {
    console.log("fuck");
    this.router.navigate(["loginhome/profile"]);
  }
  statusofPage2() {
    this.router.navigate(["loginhome/donate"]);
  }
  // getuser() {
  //   console.log(this.alluser1);
  //   console.log(this.alluser1[0].book[0].bookName);
  // }
  logout() {
    console.log("logout clicked");
    sessionStorage.removeItem('loggedInUser');
    sessionStorage.removeItem('loggedInUserId');
    sessionStorage.removeItem('ALLUSERS');

    this.router.navigate(["/"]).then(() => {
      window.location.reload();
    })

    this.svc.isLogOut();
  }


}


