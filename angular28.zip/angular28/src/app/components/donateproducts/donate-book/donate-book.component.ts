import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-donate-book',
  templateUrl: './donate-book.component.html',
  styleUrls: ['./donate-book.component.css']
})
export class DonateBookComponent implements OnInit {
  bookForm: FormGroup;
  book: any;
  selectedFile: File;
  status: boolean = false;
  msg: string = "";
  path: any;
  username: any;
  EandP: any;
  constructor(private svc: RestService) { }

  ngOnInit() {

    this.bookForm = new FormGroup({
      bookName: new FormControl(),
      bookDetails: new FormControl(),
      bookQuantity: new FormControl(),
      suggestion: new FormControl(),
      image: new FormControl()
      // categoryName: new FormControl(),
    });


  }





  Submit() {

    this.book = {
      bookName: this.bookForm.get('bookName').value,
      bookDetails: this.bookForm.get('bookDetails').value,
      bookQuantity: this.bookForm.get('bookQuantity').value,
      categoryName: localStorage.getItem("category"),
      userId: sessionStorage.getItem("loggedInUserId"),
      suggestion: this.bookForm.get('suggestion'),
      image: this.selectedFile
    }
    console.log(this.book);
    this.donate(this.book);

  }







  onFileChanged(event) {
    this.selectedFile = event.target.files[0];

    this.path = event.target.files;

    console.log("egfiueguek");
    console.log(this.path);
    console.log(this.selectedFile);


  }


  
  donate(book) {
    // this.username = sessionStorage.getItem("loggedInUser");
    // this.EandP = {
    //   email: this.username.email,
    //   productName: book.bookName
    // }
    // console.log(this.EandP);



    console.log(book);
    this.svc.donate(book).then(

      response => {

        console.log(response);
        this.status = true;
        this.msg = "Book Donation successful";


        // this.svc.getmailfordonation(this.EandP).then(response => {
        //   console.log(response);
        // this.status = true;
        // this.msg = "Book Donation successful";



        // }).catch(error => {
        //   console.log(error);
        // this.msg = "Invalid";
        // this.msg = "Book Donation unsuccessful";

        // }
        // )

      }).catch(error => {
        console.log(error);
        // this.msg = "Invalid";

       this.msg = "Book Donation unsuccessful";

      }
      )
  }

}
