import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonateElectronicComponent } from './donate-electronic.component';

describe('DonateElectronicComponent', () => {
  let component: DonateElectronicComponent;
  let fixture: ComponentFixture<DonateElectronicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonateElectronicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonateElectronicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
