import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testimage',
  templateUrl: './testimage.component.html',
  styleUrls: ['./testimage.component.css']
})
export class TestimageComponent implements OnInit {

  alluser1 = 
    {
      userId: 2,
      name: "prasad",
      email: "onkar@123",
      password: "N/A",
      image: null,
      contact: {
        contactNo: 222222,
      },
      address: {
        addressId: 1,
        address: "pune",
        pinCode: 123456789,
      },
      book: [
        { bookId: 4, bookName: "name1", bookDetails: "very good book", bookQuantity: 2, suggestion: null },
        { bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null }
      ],
      electronic:[
        {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
      ],
      dob: "2020-01-10",
    }
  constructor() { }

  ngOnInit() {
  }

}
