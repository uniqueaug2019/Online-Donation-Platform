import { Component, OnInit } from '@angular/core';



import { DomSanitizer } from '@angular/platform-browser';
import { RouterModule, Router } from '@angular/router';
import { RestService } from 'src/app/service/rest.service';



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  loggedinUser: any;
  base64textString: any;
  imagePath: any;
  alluser1: any;
  stringUser: any;
  book: any[];
  // alluser1 = 
  //   {
  //     userId: 2,
  //     name: "prasad",
  //     email: "onkar@123",
  //     password: "N/A",
  //     image: null,
  //     contact: {
  //       contactNo: 222222,
  //     },
  //     address: {
  //       addressId: 1,
  //       address: "pune",
  //       pinCode: 123456789,
  //     },
  //     book: [
  //       { bookId: 4, bookName: "name1", bookDetails: "very good book", bookQuantity: 2, suggestion: null },
  //       { bookId: 5, bookName: "qefqwe", bookDetails: "qefewq", bookQuantity: 1, suggestion: null }
  //     ],
  //     electronic:[
  //       {electronicId: 1, electronicName: "mixer", electronicDetail: "fine condition", electronicQuantity: 1, suggestion: null}
  //     ],
  //     dob: "2020-01-10",
  //   }
  // imagePath: any;
  // base64textString: string;

  constructor(private _sanitizer: DomSanitizer, private router: Router, private svc: RestService) { }




  ngOnInit() {

    console.log(this.loggedinUser);

    // this.oneuser=sessionStorage.getItem("loggedInUser");
    // console.log(JSON.parse(this.oneuser).name);
    this.loggedinUser = sessionStorage.getItem("loggedInUser");
    this.stringUser = JSON.parse(this.loggedinUser)

    console.log("in init profile");
    console.log(this.stringUser.name);
    console.log(this.loggedinUser);


    this.alluser1 =
    {
      userId: this.stringUser.userId,
      name: this.stringUser.name,
      email: this.stringUser.email,
      password: "N/A",
      image: this.stringUser.image,
      contact: {
        contactNo: this.stringUser.contact.contactNo,
      },
      address: {
        addressId: this.stringUser.address.addressId,
        address: this.stringUser.address.address,
        pinCode: this.stringUser.address.pinCode,
      },
      book: this.stringUser.book,

      electronic: this.stringUser.book,
      dob: this.stringUser.dob,
    }


    console.log("alluser1...................");

    console.log(this.alluser1);
    this.base64textString = this.stringUser.image;
    this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
      + this.base64textString);
    console.log(this.imagePath)

  }

  goback() {
    this.router.navigate(["loginhome"])
  }

  deletebook(bookId) {
    this.svc.deletebook(bookId).then(response => {
      console.log(response);



    }).catch(error => {
      console.log(error);
    }
    )

  }
  // getimagesanitizer() {
  //   this.base64textString=this.loggedinUser.image;
  //   this.imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
  //     + this.base64textString);
  // }

}
