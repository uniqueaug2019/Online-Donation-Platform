package spring.donation.donation.service;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import spring.donation.donation.pojos.User;

public interface ICategoryService {
	public boolean InsertBook(String book,User u) throws JsonMappingException, JsonProcessingException ;
}
