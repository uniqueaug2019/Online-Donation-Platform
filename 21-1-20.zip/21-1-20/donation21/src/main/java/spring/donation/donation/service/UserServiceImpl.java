package spring.donation.donation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring.donation.donation.daos.IUserDao;
import spring.donation.donation.pojos.Address;
import spring.donation.donation.pojos.Contact;
import spring.donation.donation.pojos.User;

@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	IUserDao dao;

	@Override
	public User authenticate(User user) {
		System.out.println("in user authenticate");
		
		/*
		 * User temp = new User(); temp.setEmail(user.getEmail());
		 * temp.setPassword(user.getPassword()); Example<User> eu =
		 * Example.of(temp);//search for object in table Optional<User> optional =
		 * dao.findOne(eu);// check user if (optional.isPresent()) { return
		 * optional.get(); } return null;
		 */		
		  List<User> t=dao.findByEmailPassord(user.getEmail(), user.getPassword());
		  User tempuser=t.get(0);
		  return tempuser;
		 
	}

	@Override
	public boolean register(String user) throws JsonMappingException, JsonProcessingException {
		boolean status = false;

		ObjectMapper mapper = new ObjectMapper();
		// convert to json object
		JsonNode jsonNode = mapper.readTree(user);
		System.out.println(jsonNode.toString());
		// get value for a key
		// System.out.println(jsonNode.get("dOB").asText());
		// converting json data to proper datatype
		String name = jsonNode.get("name").asText();
		String email = jsonNode.get("email").asText();
		String password = jsonNode.get("password").asText();
		String dOB = jsonNode.get("dOB").asText();
		String add = jsonNode.get("add").asText();
		int contactNo = jsonNode.get("contactNo").asInt();
		int pinCode = jsonNode.get("pinCode").asInt();
		// create user
		User u = new User(name, email, password, dOB, new Contact(contactNo));
		// create address
		Address a = new Address(add, pinCode);
		// add address using helper function
		u.addAddress(a);
		// save into db
		dao.save(u);
		return status;

	}
}