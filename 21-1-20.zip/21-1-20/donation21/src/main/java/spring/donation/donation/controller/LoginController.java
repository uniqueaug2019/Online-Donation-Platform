package spring.donation.donation.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.util.JSONPObject;

import spring.donation.donation.pojos.User;
import spring.donation.donation.service.UserServiceImpl;
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
@Scope("se")
public class LoginController {
	@Autowired//service object injection
	UserServiceImpl service;
	
    @RequestMapping(value="/login",method = RequestMethod.POST)
	public ResponseEntity<?>login(@RequestBody User user,HttpSession hs)
	{
    	System.out.println(user);
    	User temp=service.authenticate(user);

    	//set username in session
    	hs.setAttribute("name","onkar");   	
    	hs.setAttribute("curuser", temp);
    	if(temp!=null)
    	{
    		return new ResponseEntity<User>(temp,HttpStatus.OK);
    	} 
		return new ResponseEntity<String>("Auth Failed",HttpStatus.NOT_FOUND);
	}
    
    @RequestMapping(value = "/register",method=RequestMethod.POST)
    public boolean Register(@RequestBody String user,HttpSession hs)  throws JsonMappingException, JsonProcessingException
    {   
    	System.out.println("user name is"+hs.getAttribute("name"));
    	System.out.println("user data is:"+user);
    	return service.register(user); 	
    }
    
    @RequestMapping("/hello")
    public String hello(HttpSession hs)
    {   	
    	return "<h2>HELLO</h2>";
    }
}
