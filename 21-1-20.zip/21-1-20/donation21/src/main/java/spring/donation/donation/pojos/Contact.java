package spring.donation.donation.pojos;

import java.time.LocalDate;

import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Embeddable;



@Embeddable
public class Contact {
@Column(name="ContactNo",unique = true,length = 10)
private long contactNo;

public Contact() {
	// TODO Auto-generated constructor stub
}
public Contact(int contactNo) {
	super();
	this.contactNo = contactNo;
}
public long getContactNo() {
	return contactNo;
}
public void setContactNo(int contactNo) {
	this.contactNo = contactNo;
}
@Override
public String toString() {
	return "Contact [contactNo=" + contactNo + "]";
}


}


