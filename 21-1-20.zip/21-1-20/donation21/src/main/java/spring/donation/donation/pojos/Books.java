package spring.donation.donation.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Books {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookId;
	private String bookName;
	private String bookDetails;
	public User getBookuser() {
		return bookuser;
	}

	public void setBookuser(User bookuser) {
		this.bookuser = bookuser;
	}

	private int bookQuantity;

	@ManyToOne
	@JoinColumn(name = "categoryId")
	private Category selectedCategory;

	@ManyToOne
	@JoinColumn(name = "userId")
	private User bookuser;

	public Books() {
		System.out.println("inside book CTOR");
	}

	public Books(String bookName, String bookDetails, int bookQuantity, Category selectedCategory) {
		super();

		this.bookName = bookName;
		this.bookDetails = bookDetails;
		this.bookQuantity = bookQuantity;
		this.selectedCategory = selectedCategory;
	}

	public Books(String bookName, String bookDetails, int bookQuantity) {
		super();
		this.bookName = bookName;
		this.bookDetails = bookDetails;
		this.bookQuantity = bookQuantity;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookDetails() {
		return bookDetails;
	}

	public void setBookDetails(String bookDetails) {
		this.bookDetails = bookDetails;
	}

	public int getBookQuantity() {
		return bookQuantity;
	}

	public void setBookQuantity(int bookQuantity) {
		this.bookQuantity = bookQuantity;
	}

	public Category getSelectedCategory() {
		return selectedCategory;
	}

	public void setSelectedCategory(Category selectedCategory) {
		this.selectedCategory = selectedCategory;
	}

	@Override
	public String toString() {
		return "Books [bookId=" + bookId + ", bookName=" + bookName + ", bookDetails=" + bookDetails + ", bookQuantity="
				+ bookQuantity + ", selectedCategory=" + selectedCategory + "]";
	}

}
