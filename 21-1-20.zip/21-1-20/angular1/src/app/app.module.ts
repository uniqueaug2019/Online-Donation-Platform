import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'

import { ReactiveFormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { FormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './components/register/register.component';
import { BuyproductsComponent } from './components/buyproducts/buyproducts.component';
import { DonateproductsComponent } from './components/donateproducts/donateproducts.component';
import { DonateBookComponent } from './components/donateproducts/donate-book/donate-book.component';
import { DonateElectronicComponent } from './components/donateproducts/donate-electronic/donate-electronic.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login/buy', component: BuyproductsComponent },
  { path: 'login/donate', component: DonateproductsComponent },
  { path: 'login/donate/books', component:DonateBookComponent},
  { path: 'login/donate/electronics', component: DonateElectronicComponent }
]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    BuyproductsComponent,
    DonateproductsComponent,
    DonateBookComponent,
    DonateElectronicComponent,
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
