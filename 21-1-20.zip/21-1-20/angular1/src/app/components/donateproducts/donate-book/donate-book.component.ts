import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/service/rest.service';

@Component({
  selector: 'app-donate-book',
  templateUrl: './donate-book.component.html',
  styleUrls: ['./donate-book.component.css']
})
export class DonateBookComponent implements OnInit {

  constructor(private svc:RestService ) { }

  ngOnInit() {
  }


  donate(book) {
    console.log(book);
    this.svc.donate(book).then(response => {
      console.log(response);
     
      
      // this.msg = "Login successful";

    }).catch(error => {
      console.log(error);
      // this.msg = "Invalid";

    }
    )
  }

}
