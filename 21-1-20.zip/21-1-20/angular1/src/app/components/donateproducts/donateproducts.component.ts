import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donateproducts',
  templateUrl: './donateproducts.component.html',
  styleUrls: ['./donateproducts.component.css']
})
export class DonateproductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
