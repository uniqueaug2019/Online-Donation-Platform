package spring.donation.donation.service;

import spring.donation.donation.pojos.User;

public interface IUserService {
public User authnticate(User user);
}
